---
id: 448559134
title: CityCampNews
date: 2011-10-01T00:25:37-05:00
author: Luke Fretwell
layout: page
guid: http://citycamp.govfresh.com/?page_id=448559134
dsq_thread_id:
  - "2354158603"
dpsp_networks_shares:
  - 'a:1:{s:9:"pinterest";i:0;}'
dpsp_networks_shares_total:
  - "0"
dpsp_networks_shares_last_updated:
  - "1631726093"
---
