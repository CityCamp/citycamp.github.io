---
id: 448558514
title: San Francisco CIO Chris Vein and Tim O’Reilly
date: 2010-08-06T16:20:59-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/349185882-revision-4/
permalink: /?p=448558514
---
<a href="http://citycamp.govfresh.com/timoreilly-amp-sfcitycio-conversation-citycamp/vein/" rel="attachment wp-att-448558483"><img loading="lazy" src="http://citycamp.govfresh.com/files/2010/01/vein-550x412.png" alt="San Francisco CIO Chris Vein and Tim O&#039;Reilly" title="San Francisco CIO Chris Vein and Tim O&#039;Reilly" width="550" height="412" class="alignnone size-medium wp-image-448558483" /></a>