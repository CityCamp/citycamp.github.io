---
id: 448559247
title: 'CityCampers: Submit and vote for the 2011 GovFresh Awards'
date: 2011-12-05T20:43:52-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448559245-revision/
permalink: /?p=448559247
---
[<img loading="lazy" src="http://govfresh.com/wp-content/uploads/2011/12/gfa2011.jpg" alt="2011 GovFresh Awards" title="2011 GovFresh Awards" width="610" height="180" />](http://awards.govfresh.com)

Every day, tech-minded citizens across the country are doing good by their communities, literally geeking out about how they can help re-define the relationship government has with its citizens, using technology as a democratic tool to collaboratively empower both.

So much is happening in the civic technology community &#8211; website redesigns, new websites, open data initiatives, apps, camps, developer contests, hackathons and more &#8211; it&#8217;s hard to get a perspective on or truly appreciate the collective work of these dot-dogooders both inside and outside government.

That&#8217;s why we created the [2011 GovFresh Awards](http://awards.govfresh.com).

It&#8217;s time to recognize and honor all that&#8217;s been accomplished this year.

It&#8217;s time to say thank you.

Here are the categories. Start entering and start voting.

  * [City of the Year](http://govfresh.uservoice.com/forums/142162-city-of-the-year)
  * [Public Servant of the Year](http://govfresh.uservoice.com/forums/142165-2011-govfresh-awards)
  * [Citizen of the Year](http://govfresh.uservoice.com/forums/142166-2011-govfresh-awards)
  * [App of the Year](http://govfresh.uservoice.com/forums/142167-2011-govfresh-awards)
  * [Best Government/Citizen Collaboration](http://govfresh.uservoice.com/forums/142168-2011-govfresh-awards)
  * [Best Use of Open Source](http://govfresh.uservoice.com/forums/142169-2011-govfresh-awards)
  * [Best Open and Participatory Budgeting Initiative](http://govfresh.uservoice.com/forums/142170-2011-govfresh-awards)
  * [Best Open Government Policy](http://govfresh.uservoice.com/forums/142171-2011-govfresh-awards)
  * [Best Open Data Platform](http://govfresh.uservoice.com/forums/142172-2011-govfresh-awards)
  * [Best Civic Hackathon](http://govfresh.uservoice.com/forums/142173-2011-govfresh-awards)
  * [Best Civic Start-up](http://govfresh.uservoice.com/forums/142174-2011-govfresh-awards)
  * [Best Use of Social Media](http://govfresh.uservoice.com/forums/142175-2011-govfresh-awards)
  * [Best Use of Social Media for Emergency Management](http://govfresh.uservoice.com/forums/142176-2011-govfresh-awards)
  * [Best Transit App](http://govfresh.uservoice.com/forums/142177-2011-govfresh-awards)
  * [Best 311 App](http://govfresh.uservoice.com/forums/142178-2011-govfresh-awards)
  * [Best Emergency Management App](http://govfresh.uservoice.com/forums/142179-2011-govfresh-awards)
  * [Best Social Services App](http://govfresh.uservoice.com/forums/142180-2011-govfresh-awards)