---
id: 448559217
title: Request for Comments
date: 2011-11-21T18:36:34-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559211-revision-6/
permalink: /?p=448559217
---
<div>
  <div style="width: 330px" class="wp-caption alignright">
    <a href="http://en.wikipedia.org/wiki/Open_data"><img loading="lazy" title="Open Data Labels" src="http://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Open_Data_stickers.jpg/320px-Open_Data_stickers.jpg" alt="Open Data Labels" width="320" height="240" /></a>
    
    <p class="wp-caption-text">
      source: Wikipedia
    </p>
  </div>
  
  <p>
    <a title="CityCampSF" href="http://citycampsf.govfresh.com" target="_blank">CityCampSF</a> organizer Adriel Hampton is working legislation to come up with a legal definition of open data in California. The definition will be used as a test for a requirement for the government to publish according to the definition. Note Adriel&#8217;s comments in the discussion. He specifically has been asked to address phrase like &#8220;commonly used Web search applications and commonly used software.&#8221; Also, there is a challenge to the no-cost claim. Please lend your expertise by commenting here.</div> 
    
    <p>
      <a href="http://www.wiredtoshare.com/briefing_doc_structured_open_data_sf_ca" target="_blank">http://www.wiredtoshare.com/<wbr>briefing_doc_structured_open_<wbr>data_sf_ca</wbr></wbr></a>
    </p>