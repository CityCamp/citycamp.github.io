---
id: 448558534
title: Welcome to CityCamp!
date: 2010-08-06T22:04:54-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision/
permalink: /?p=448558534
---
CityCamp is an unconference focused on innovation for municipal governments and community organizations.