---
id: 22
title: Connect
date: 2010-08-03T21:29:57-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/2010/08/03/7-revision-3/
permalink: /?p=22
---
How do I connect with CityCampers?

  * Twitter: <a href="http://twitter.com/CityCamp" target="_blank">@CityCamp</a> and <a href="http://twitter.com/CityCampLDN" target="_blank">@CityCampLDN</a>
  * Hashtags:  [#citycamp](http://twitter.com/#search?q=citycamp) and [#citycampLDN](http://twitter.com/#search?q=citycampLDN)
  * E-mail List: <http://forums.e-democracy.org/groups/citycamp>
  * Facebook: <http://www.facebook.com/group.php?gid=130953577981>
  * GovLoop: <http://www.govloop.com/group/citycamp>
  * Delicious: <http://delicious.com/tag/CityCamp>
  * USE YOUR OWN LOCAL CHANNELS TO CONNECT DURING YOUR OWN CAMPS

<!--GroupSever Signup Form-->