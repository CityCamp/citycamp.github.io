---
id: 448559377
title: Home
date: 2014-10-05T17:10:38-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448559134-revision-v1/
permalink: /?p=448559377
---
CityCamp is an international unconference series and online community focused on innovation for municipal governments and community organizations.