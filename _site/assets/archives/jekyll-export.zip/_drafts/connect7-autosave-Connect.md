---
id: 448558882
title: Connect
date: 2011-02-12T00:24:17-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/7-autosave/
permalink: /?p=448558882
---
How do I connect with CityCampers?

  * Twitter: <a href="http://twitter.com/CityCamp" target="_blank">@CityCamp</a>
  * Hashtag:  [#citycamp](http://twitter.com/#search?q=citycamp)
  * Forum & E-mail List: <http://forums.e-democracy.org/groups/citycamp>
  * Facebook: <http://www.facebook.com/group.php?gid=130953577981>
  * GovLoop: <http://www.govloop.com/group/citycamp>
  * LinkedIn: <http://www.linkedin.com/groups/CityCamp-3766334>
  * Delicious: <http://delicious.com/tag/CityCamp>

<!--GroupSever Signup Form-->