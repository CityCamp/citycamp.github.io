---
id: 448558470
title: Day 1, Session 1 Reports
date: 2010-01-26T20:53:31-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/355275833-revision/
permalink: /?p=448558470
---
[youtube=]