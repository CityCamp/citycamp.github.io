---
id: 448558724
title: Crime Data Conversation Highlights Key Issues of Open Data
date: 2010-09-23T21:59:28-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558723-revision/
permalink: /?p=448558724
---
Here is a conversation taking place on the CityCamp forum regarding use of crime data:

<http://forums.e-democracy.org/groups/citycamp/messages/topic/5GuO4Ncez37MyWcBgMxoJs>

This is a great &#8220;one-stop&#8221; resource for high level and in-depth information on this vital topic.