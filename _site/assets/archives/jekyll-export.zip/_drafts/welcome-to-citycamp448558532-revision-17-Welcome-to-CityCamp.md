---
id: 448558552
title: Welcome to CityCamp!
date: 2010-08-06T22:33:17-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-17/
permalink: /?p=448558552
---
<img loading="lazy" src="http://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z-550x185.jpg" alt="Welcome to CityCamp!" title="Welcome to CityCamp!" width="550" height="185" class="alignnone size-medium wp-image-448558533" srcset="https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z-550x185.jpg 550w, https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z-400x135.jpg 400w, https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z.jpg 640w" sizes="(max-width: 550px) 100vw, 550px" />

CityCamp is an unconference focused on innovation for municipal governments and community organizations. [Learn more &raquo;](http://citycamp.govfresh.com/about/)