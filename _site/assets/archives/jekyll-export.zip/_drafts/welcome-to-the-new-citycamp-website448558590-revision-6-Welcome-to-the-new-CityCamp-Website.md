---
id: 448558596
title: Welcome to the new CityCamp Website!
date: 2010-08-11T12:37:22-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558590-revision-6/
permalink: /?p=448558596
---
[<img loading="lazy" src="http://citycamp.govfresh.com/files/2010/08/Picture-2-550x323.png" alt="New CityCamp Website!" title="New CityCamp Website!" width="550" height="323" class="alignnone size-medium wp-image-448558518" srcset="https://citycamp.govfresh.com/files/2010/08/Picture-2-550x323.png 550w, https://citycamp.govfresh.com/files/2010/08/Picture-2-768x452.png 768w, https://citycamp.govfresh.com/files/2010/08/Picture-2-900x529.png 900w, https://citycamp.govfresh.com/files/2010/08/Picture-2.png 1092w" sizes="(max-width: 550px) 100vw, 550px" />](http://citycamp.govfresh.com)

As part of our efforts to promote the CityCamp Word Tour, we&#8217;re working with [GovFresh](http://govfresh.com) to create this new hub for all things CityCamp.

There&#8217;s still an open [barcamp wiki](http://barcamp.org/CityCamp) and a [public forum](http://forums.e-democracy.org/groups/citycamp). This site brings it all together through a common portal with a great look and feel. In fact, our hope is that this site will help establish CityCamp as an &#8216;[open source brand](http://citycamp.govfresh.com/citycamp-as-an-open-source-brand/),&#8217; something that is both easily repeatable and recognizable for anyone to use. That&#8217;s why we put CityCamp in the Creative Commons. There will be a few rules to follow, but as few as possible. We haven&#8217;t completely worked out those details but didn&#8217;t want to wait to get started.