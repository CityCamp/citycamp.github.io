---
id: 45
title: 'CityCamp as an &#8220;Open Source Brand&#8221;'
date: 2010-08-03T22:56:21-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/36-revision-7/
permalink: /?p=45
---
We&#8217;re working on making CityCamp an &#8220;open source brand.&#8221;  CityCamp should exist in the Creative Commons (license terms pending).  Open source ensures that CityCamp is maintained as a pattern that is easily repeatable and for anyone to use.  Branding ensures that the pattern is recognizable and that independent organizers don’t misrepresent CityCamp.   No one organization will own CityCamp.  Instead it will be maintained by a dedicated community of local organizers.