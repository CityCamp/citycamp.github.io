---
id: 448559139
title: Welcome to CityCamp!
date: 2011-02-11T23:37:14-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-19/
permalink: /?p=448559139
---
CityCamp is an international unconference series and online community focused on innovation for municipal governments and community organizations. [Learn more »](http://citycamp.govfresh.com/about/)