---
id: 448558923
title: CityCamp-GovLoop Meetups
date: 2011-03-02T20:17:32-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558908-revision-15/
permalink: /?p=448558923
---
We&#8217;ve been hosting meetups all over. Some cities are recapping what&#8217;s happened locally since their camps. Other cities are being introduced to CityCamp for the first time. Don&#8217;t see a meetup where you live? Host one!