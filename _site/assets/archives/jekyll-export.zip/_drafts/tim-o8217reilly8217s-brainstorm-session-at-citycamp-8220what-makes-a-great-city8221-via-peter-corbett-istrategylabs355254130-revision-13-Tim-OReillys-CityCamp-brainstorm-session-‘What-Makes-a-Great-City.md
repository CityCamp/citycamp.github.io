---
id: 448558645
title: Tim O’Reilly’s CityCamp brainstorm session ‘What Makes a Great City?’
date: 2010-08-19T22:56:42-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/355254130-revision-13/
permalink: /?p=448558645
---
Video is by Peter Corbett, [iStrategy Labs](http://istrategylabs.com/ "home page")