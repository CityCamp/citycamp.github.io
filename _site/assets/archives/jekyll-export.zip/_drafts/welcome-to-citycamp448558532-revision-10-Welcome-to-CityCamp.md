---
id: 448558545
title: Welcome to CityCamp!
date: 2010-08-06T22:18:59-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-10/
permalink: /?p=448558545
---
<a href="http://citycamp.govfresh.com/welcome-to-citycamp/3479423122_d223321dbd_z-2/" rel="attachment wp-att-448558543"><img loading="lazy" src="http://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z1-550x366.jpg" alt="Welcome to CityCamp!" title="Welcome to CityCamp!" width="550" height="366" class="alignnone size-medium wp-image-448558543" srcset="https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z1-550x366.jpg 550w, https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z1-400x266.jpg 400w, https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z1.jpg 640w" sizes="(max-width: 550px) 100vw, 550px" /></a>

CityCamp is an unconference focused on innovation for municipal governments and community organizations.