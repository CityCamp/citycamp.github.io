---
id: 448559354
title: CityCamp Turns 3
date: 2013-01-25T00:48:04-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559349-revision-4/
permalink: /?p=448559354
---
Alpha CityCamper Andre Natta (@acnatta) reminded me on Twitter that it&#8217;s been 3 years since the inaugural CityCamp:  
<http://barcamp.org/w/page/25504543/CityCamp-Original>

In that time there have been 3o CityCamps independently organized BY YOU in  
25 cities across 8 countries and 5 continents:  
<http://citycamp.govfresh.com/cities>

Always a fun time to scroll back through the Introductions thread&#8230;  
<http://forums.e-democracy.org/groups/citycamp/messages/topic/5tikRb8TaKCI4ba31BLrH3>

&#8230;and look way back on the CityCamp Tumblr:  
<http://citycamp.tumblr.com/page/7>