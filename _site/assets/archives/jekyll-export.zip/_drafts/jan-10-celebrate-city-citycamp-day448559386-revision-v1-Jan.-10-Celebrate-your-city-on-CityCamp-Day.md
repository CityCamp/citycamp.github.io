---
id: 448559387
title: 'Jan. 10: Celebrate your city on CityCamp Day'
date: 2014-10-27T23:20:37-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448559386-revision-v1/
permalink: /?p=448559387
---
[<img loading="lazy" src="http://citycamp.govfresh.com/files/2014/10/cropped-logo.png" alt="CityCamp" width="307" height="77" class="alignright size-full wp-image-448559376" />](http://citycamp.com)

To celebrate the fifth anniversary of [CityCamp](http://citycamp.com), we&#8217;re encouraging cities across the world to celebrate [CityCamp Day](http://citycamp.com) on January 10, 2015.

For those unfamiliar with the concept, [CityCamp](http://citycamp.com) is an unconference focused on innovation and collaboration for municipal governments, community organizations and citizens.

[CityCamp](http://citycamp.com) aims to:

  * Bring together local government officials, municipal employees, experts, developers, designers, citizens and journalists to share perspectives and insights about their cities
  * Create outcomes that participants will act upon

Here&#8217;s how to get started:

  * [Start a CityCamp](https://docs.google.com/document/d/1AWfTSB1MMbWCdgzuESQF4izY8vKBxRAC_Afch-8uRCQ/edit?usp=sharing) where you live
  * [Add your city](https://github.com/CityCamp/add-your-city/blob/master/README.md) to the CityCamp website

Learn more about [CityCamp](http://citycamp.com) at [citycamp.com](http://citycamp.com), follow on [Twitter](http://twitter.com/citycamp) and [Facebook](http://facebook.com/citycamp) and sign up for the [newsletter](http://tinyletter.com/citycamp).

Please feel free to contact me at luke@govfresh.com if you have questions or need help.