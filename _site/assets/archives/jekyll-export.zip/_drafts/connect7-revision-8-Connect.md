---
id: 448558881
title: Connect
date: 2010-08-27T17:31:46-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/7-revision-8/
permalink: /?p=448558881
---
How do I connect with CityCampers?

  * Twitter: <a href="http://twitter.com/CityCamp" target="_blank">@CityCamp</a>
  * Hashtags:  [#citycamp](http://twitter.com/#search?q=citycamp)
  * E-mail List: <http://forums.e-democracy.org/groups/citycamp>
  * Facebook: <http://www.facebook.com/group.php?gid=130953577981>
  * GovLoop: <http://www.govloop.com/group/citycamp>
  * Delicious: <http://delicious.com/tag/CityCamp>

<!--GroupSever Signup Form-->