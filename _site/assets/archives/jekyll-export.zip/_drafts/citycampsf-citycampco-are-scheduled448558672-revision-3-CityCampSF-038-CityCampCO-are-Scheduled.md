---
id: 448558677
title: 'CityCampSF &#038; CityCampCO are Scheduled!'
date: 2010-09-06T22:36:16-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558672-revision-3/
permalink: /?p=448558677
---
The CityCamp World Tour continues with camps set in [San Francisco](http://citycampsf.govfresh.com "home"), October 8-10 and in the [&#8220;Front Range&#8221; cities of Colorado](http://citycampco.govfresh.com "home"), December 4-5.

[<img loading="lazy" class="size-medium wp-image-448558675 alignleft" title="CityCampSF" src="http://citycamp.govfresh.com/files/2010/09/CityCampSF-550x451.png" alt="" width="550" height="451" srcset="https://citycamp.govfresh.com/files/2010/09/CityCampSF-550x451.png 550w, https://citycamp.govfresh.com/files/2010/09/CityCampSF-768x630.png 768w, https://citycamp.govfresh.com/files/2010/09/CityCampSF-731x600.png 731w, https://citycamp.govfresh.com/files/2010/09/CityCampSF.png 997w" sizes="(max-width: 550px) 100vw, 550px" />](http://citycamp.govfresh.com/files/2010/09/CityCampSF.png)[<img loading="lazy" class="alignright size-medium wp-image-448558674" title="CityCampCO" src="http://citycamp.govfresh.com/files/2010/09/CityCampCO-550x486.png" alt="" width="550" height="486" srcset="https://citycamp.govfresh.com/files/2010/09/CityCampCO-550x486.png 550w, https://citycamp.govfresh.com/files/2010/09/CityCampCO-677x600.png 677w, https://citycamp.govfresh.com/files/2010/09/CityCampCO-400x353.png 400w, https://citycamp.govfresh.com/files/2010/09/CityCampCO.png 991w" sizes="(max-width: 550px) 100vw, 550px" />](http://citycamp.govfresh.com/files/2010/09/CityCampCO.png)