---
id: 448558468
title: Juan-Pablo Velez offers his three take-aways from City Camp
date: 2010-08-05T00:55:49-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448555545-revision-2/
permalink: /?p=448558468
---
