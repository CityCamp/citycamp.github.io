---
id: 448558469
title: Mark Kuznicki challenges City Campers
date: 2010-08-05T00:50:23-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558415-revision-2/
permalink: /?p=448558469
---
