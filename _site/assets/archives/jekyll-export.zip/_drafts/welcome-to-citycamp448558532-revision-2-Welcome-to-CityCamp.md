---
id: 448558535
title: Welcome to CityCamp!
date: 2010-08-06T22:05:54-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-2/
permalink: /?p=448558535
---
<a href="http://citycamp.govfresh.com/?attachment_id=448558533" rel="attachment wp-att-448558533"><img loading="lazy" src="http://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z-550x185.jpg" alt="Welcome to CityCamp!" title="Welcome to CityCamp!" width="550" height="185" class="alignnone size-medium wp-image-448558533" srcset="https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z-550x185.jpg 550w, https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z-400x135.jpg 400w, https://citycamp.govfresh.com/files/2010/08/3479423122_d223321dbd_z.jpg 640w" sizes="(max-width: 550px) 100vw, 550px" /></a>

CityCamp is an unconference focused on innovation for municipal governments and community organizations.