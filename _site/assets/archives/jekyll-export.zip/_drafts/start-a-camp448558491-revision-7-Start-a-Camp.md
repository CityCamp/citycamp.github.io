---
id: 448558638
title: Start a Camp
date: 2010-08-11T12:40:29-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558491-revision-7/
permalink: /?p=448558638
---
Contact us for help starting a CityCamp where you live:

[contact-form 1 &#8220;Contact form 1&#8221;]