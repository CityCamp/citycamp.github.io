---
id: 448558809
title: CityCamp One Year Later
date: 2011-01-23T20:59:11-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558804-revision-5/
permalink: /?p=448558809
---
Today marks one year since [the first CityCamp](barcamp.org/CityCamp-Original "barcamp wiki") in Chicago, Illinois.  As is customary, it&#8217;s time to take time to reflect on what has transpired in the year since that fateful weekend.

By the Numbers:

# 6

The number of [cities](http://citycamp.govfresh.com/cities/ "cities") that have held a CityCamp

# 800

Roughly the number of people who attended CityCamps last year.  (About twice as many registered, which means they at least visited our pages.)