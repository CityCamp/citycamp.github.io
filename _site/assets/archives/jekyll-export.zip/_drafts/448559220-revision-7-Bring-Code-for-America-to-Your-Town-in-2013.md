---
id: 448559227
title: Bring Code for America to Your Town in 2013!
date: 2011-11-27T23:37:39-05:00
author: alissa
layout: revision
guid: http://citycamp.govfresh.com/448559220-revision-7/
permalink: /?p=448559227
---
<table width="708" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
  <tr>
    <td align="center" valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
        <tr align="left">
          <td width="20">
            <img loading="lazy" src="http://img.gotomeeting.com/g2mimages/1x1.gif" alt="" width="20" height="1" />
          </td>
          
          <td width="668">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top">
                  <img loading="lazy" src="http://www3.gotomeeting.com/g2w/images/483299846/246501580964588242//embed.jpg" alt="" width="319" height="141" />
                </td>
              </tr>
              
              <tr>
                <td height="30">
                </td>
              </tr>
              
              <tr>
                <td>
                  <span style="color: #000000;font-family: arial, verdana, helvetica">Code for America&#8217;s Fellowship Program</span>
                </td>
              </tr>
              
              <tr>
                <td width="100%">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr valign="top">
                      <td>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td>
                              <span style="color: #0077dd;font-family: arial, verdana, helvetica">Join us for a Webinar on December 13</span>
                            </td>
                          </tr>
                          
                          <tr>
                            <td>
                              <a href="https://www3.gotomeeting.com/register/483299846" target="_blank"><img src="http://img.gotomeeting.com/g2mimages/webinar/themes/basic/button_registerNow.gif" alt="" width="183" border="0" /></a>
                            </td>
                            
                            <td height="20">
                            </td>
                          </tr>
                          
                          <tr>
                            <td>
                              <span style="color: #000000;font-family: arial, verdana, helvetica"><strong>Space is limited.</strong><br /> Reserve your Webinar seat now at:<br /> <a href="https://www3.gotomeeting.com/register/483299846" target="_blank">https://www3.gotomeeting.com/register/483299846</a></span>
                            </td>
                          </tr>
                          
                          <tr>
                            <td height="20">
                            </td>
                          </tr>
                          
                          <tr>
                            <td>
                              <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td>
                                    <span style="color: #000000;font-family: arial, verdana, helvetica">In Code for America&#8217;s first year they built more than 40 civic applications to help government provide services more openly and efficiently, and better engage with their constituents. But more importantly Code for America&#8217;a fellowship program was a catalyst in breaking down the communication silos within and outside of government. The program isn&#8217;t just about the apps, the technology is the product of a process that has the power to transform our local governments.</p> 
                                    
                                    <p>
                                      Desiree Peterkin Bell, Director of Communications and Strategic Partnerships for Mayor Michael Nutter, and Jeff Friedman, Manager of Civic Innovation & Participation for the City of Philadelphia will be joining Alissa Black and other Code for America staff to talk about:
                                    </p>
                                    
                                    <p>
                                      &#8211; Code for America&#8217;s fellowship program<br /> &#8211; Learnings from 2011<br /> &#8211; Bringing Code for America to your city</span></td> </tr> </tbody> </table> 
                                      
                                      <table border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                          <td width="32">
                                            <span style="color: #000000;font-family: arial, verdana, helvetica"><strong>Title:</strong></span>
                                          </td>
                                          
                                          <td>
                                            <span style="color: #000000;font-family: arial, verdana, helvetica">Code for America&#8217;s Fellowship Program</span>
                                          </td>
                                        </tr>
                                        
                                        <tr>
                                          <td>
                                            <span style="color: #000000;font-family: arial, verdana, helvetica"><strong>Date:</strong></span>
                                          </td>
                                          
                                          <td>
                                            <span style="color: #000000;font-family: arial, verdana, helvetica">Tuesday, December 13, 2011</span>
                                          </td>
                                        </tr>
                                        
                                        <tr>
                                          <td>
                                            <span style="color: #000000;font-family: arial, verdana, helvetica"><strong>Time:</strong></span>
                                          </td>
                                          
                                          <td>
                                            <span style="color: #000000;font-family: arial, verdana, helvetica">11:00 AM &#8211; 12:00 PM PST</span>
                                          </td>
                                        </tr>
                                      </table>
                                      
                                      <table border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                          <td>
                                            <span><span style="font-family: arial, verdana, helvetica">After registering you will receive a confirmation email containing information about joining the Webinar.</span></span>
                                          </td>
                                        </tr>
                                      </table>