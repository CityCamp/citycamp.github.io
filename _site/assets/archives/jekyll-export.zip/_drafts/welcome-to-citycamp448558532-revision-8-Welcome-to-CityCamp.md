---
id: 448558542
title: Welcome to CityCamp!
date: 2010-08-06T22:16:30-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-8/
permalink: /?p=448558542
---
CityCamp is an unconference focused on innovation for municipal governments and community organizations.