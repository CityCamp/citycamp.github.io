---
id: 448558417
title: Juan-Pablo Velez offers his three take-aways from City Camp
date: 2010-03-14T18:38:54-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448555545-revision/
permalink: /?p=448558417
---
