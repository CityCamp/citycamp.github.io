---
id: 448559206
title: CityCampSF Hackathon Set
date: 2011-11-17T12:12:29-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559205-revision/
permalink: /?p=448559206
---
<div id="intro">
  <p>
    <a href="http://www.flickr.com/photos/adrielhampton/6278046596"><img loading="lazy" src="http://farm7.static.flickr.com/6108/6278046596_64b3dc68e8.jpg" alt="" width="500" height="375" border="0" /></a>
  </p>
  
  <p>
    Join CityCampSF, Gov 2.0 Radio, OpenSF, Third Thursdays SF and Granicus for <strong><em>24 hours</em></strong> of civic innovation!
  </p>
  
  <p>
    Challenges include:
  </p>
  
  <p>
    Best demonstration app for assessing the true impacts of clear-cutting in the Sierra Nevadas;
  </p>
  
  <p>
    Best app combining City data sources for true transparency in SF campaign donations, lobbying and contracting;
  </p>
  
  <p>
    Best use of Granicus APIs;
  </p>
  
  <p>
    We&#8217;ll also be formally launching an advocacy campaign for structured open data definitions in San Francisco municipal and California state law. Endorse that effort <a href="http://www.wiredtoshare.com/structured_open_data_campaign" target="_blank">here</a>.
  </p>
  
  <p>
    More to be announced! Submit a challenge or ask questions on the <a href="http://www.wiredtoshare.com/citycampsf_hackathon_projects" target="_blank">CityCampSF Hackathon Projects page</a>.
  </p>
  
  <p>
    If you&#8217;d like to contribute to covering the costs of the event, <a href="https://adriel.nationbuilder.com/donate" target="_blank">pitch in here</a>. Thanks!
  </p>
  
  <p>
    Read <a href="http://citycamp.govfresh.com/" target="_blank">more about CityCamp here</a>.
  </p>
</div>

<div>
  <div>
    WHEN
  </div>
  
  <div>
    December 10, 2011 at 12:00 PM &#8211; December 11, 2011 at 12:00 PM
  </div>
</div>

<div>
  <div>
    WHERE
  </div>
  
  <div>
    Granicus<br /> 600 Harrison St<br /> Suite 120<br /> San Francisco, CA 94107<br /> <a href="http://maps.google.com/maps?q=600+Harrison+St%2C+San+Francisco%2C+CA+94107">Google map and directions</a>
  </div>
</div>

<div>
  <div>
    CONTACT
  </div>
  
  <div>
    Adriel Hampton · <a title="" href="mailto:adriel@adrielhampton.com">adriel@adrielhampton.com</a> · 415-237-4299
  </div>
</div>