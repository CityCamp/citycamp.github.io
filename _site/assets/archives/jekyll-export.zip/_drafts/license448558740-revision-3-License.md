---
id: 448558744
title: License
date: 2010-10-26T08:18:18-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558740-revision-3/
permalink: /?p=448558744
---
<div id="attachment_448558743" style="width: 413px" class="wp-caption aligncenter">
  <a href="http://citycamp.govfresh.com/files/2010/10/cc-by-sa.png"><img aria-describedby="caption-attachment-448558743" loading="lazy" class="size-full wp-image-448558743" title="cc-by-sa" src="http://citycamp.govfresh.com/files/2010/10/cc-by-sa.png" alt="Creative Commons, Attributions, Share-alike" width="403" height="141" srcset="https://citycamp.govfresh.com/files/2010/10/cc-by-sa.png 403w, https://citycamp.govfresh.com/files/2010/10/cc-by-sa-400x139.png 400w" sizes="(max-width: 403px) 100vw, 403px" /></a>
  
  <p id="caption-attachment-448558743" class="wp-caption-text">
    Creative Commons, Attributions, Share-alike
  </p>
</div>