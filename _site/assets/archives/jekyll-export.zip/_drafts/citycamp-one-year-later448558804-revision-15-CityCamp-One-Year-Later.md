---
id: 448558819
title: CityCamp One Year Later
date: 2011-01-23T21:26:19-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558804-revision-15/
permalink: /?p=448558819
---
Today and tomorrow, January 23 & 24, mark one year since [the first CityCamp](barcamp.org/CityCamp-Original "barcamp wiki") in Chicago, Illinois.  As is customary, it&#8217;s time to take time to reflect on what has transpired in the year since that fateful weekend.

Here&#8217;s a little CityCamp &#8220;By the Numbers&#8221;:

# 6

The number of [cities](http://citycamp.govfresh.com/cities/ "cities") that have held a CityCamp

# 800

Roughly the number of people who attended CityCamps last year.  (About twice as many registered, which means they at least visited our pages.)

# 504

The combined number of members in CityCamp forum at [e-democracy](http://forums.e-democracy.org/groups/citycamp/ "e-dem forum") and group at [GovLoop](http://www.govloop.com/group/citycamp "GovLoop group"). (956 [Facebook fans](http://www.facebook.com/citycamp "Facebook").)

<font size="8"><strong>800 </strong>posts by <strong>336 </strong>authors in the forum.</font>