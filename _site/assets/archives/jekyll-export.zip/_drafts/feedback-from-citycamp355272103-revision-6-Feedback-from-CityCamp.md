---
id: 448558471
title: 'Feedback from #CityCamp'
date: 2010-08-05T22:08:25-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/355272103-revision-6/
permalink: /?p=448558471
---
