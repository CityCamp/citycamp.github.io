---
id: 448559107
title: FoCC
date: 2011-09-04T20:10:47-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558755-revision-27/
permalink: /?p=448559107
---
&nbsp;

## (Friends of CityCamp)

[![The Rockefeller Foundation](http://citycamp.govfresh.com/files/2010/10/rockfound.png)](http://rockfound.org/) [![O'Reilly Media](http://citycamp.govfresh.com/files/2010/10/oralogo-e1288269153400.png "Spreading the knowledge of technology innovators")](http://www.oreilly.com/ "Spreading the knowledge of technology innovators") [![Sunlight Foundation](http://citycamp.govfresh.com/files/2010/10/sunlightlogowhite-e1288268543959.gif)](http://sunlightfoundation.com/) [![GovFresh](http://citycamp.govfresh.com/files/2010/10/govfresh-e1288268660662.png)](http://govfresh.com/) [![E-Democracy.org](http://citycamp.govfresh.com/files/2010/10/e-democracy300pxRGB-e1288269366216.png)](http://e-democracy.org/) [![GovLoop](http://citycamp.govfresh.com/files/2010/10/govloop-e1288380763577.png)](http://govloop.com/) [<img loading="lazy" class="alignleft size-full wp-image-448558822" title="istrategy" src="http://citycamp.govfresh.com/files/2011/01/istrategy-e1295837023864.gif" alt="" width="150" height="87" />](http://citycamp.govfresh.com/files/2011/01/istrategy-e1295837023864.gif) [![Code for America](http://citycamp.govfresh.com/files/2010/10/codeforamerica-150x61.png)](http://codeforamerica.org/) [![Civic Commons](http://citycamp.govfresh.com/files/2010/10/civiccommons-logo-web-e1288269713206.png)](http://civiccommons.com/) [![Gov 2.0 Summit](http://citycamp.govfresh.com/files/2010/10/Gov2Summit-300x182-e1288270434373.gif "O’Reilly Media Event")](http://gov2summit.com/ "O’Reilly Media Event") [<img loading="lazy" class="alignleft size-full wp-image-448558826" title="futuregov" src="http://citycamp.govfresh.com/files/2011/01/futuregov-e1295837218866.png" alt="" width="160" height="63" />](http://citycamp.govfresh.com/files/2011/01/futuregov-e1295837218866.png) [![Open Plans](http://citycamp.govfresh.com/files/2010/10/openplans-logo-150x41.gif)](http://openplans.org/)