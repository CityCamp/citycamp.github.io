---
id: 448558803
title: Anniversary of the Inaugural CityCamp 1/24
date: 2011-01-22T13:27:44-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558800-revision-2/
permalink: /?p=448558803
---
Monday, January 24, is the one year anniversary of [the inaugural CityCamp](http://barcamp.org/CityCamp-Original). Things have been quite lately, but that&#8217;s about to change starting next week and carrying into February. Watch this page and stay tuned to [these channels](http://citycamp.govfresh.com/connect/) for breaking info.