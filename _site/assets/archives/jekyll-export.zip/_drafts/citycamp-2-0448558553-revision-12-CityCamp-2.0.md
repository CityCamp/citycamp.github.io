---
id: 448558575
title: CityCamp 2.0
date: 2010-08-10T08:06:03-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558553-revision-12/
permalink: /?p=448558575
---
[<img loading="lazy" class="alignleft size-thumbnail wp-image-448558570" src="http://citycamp.govfresh.com/files/2010/08/CityCamp5121-100x100.png" alt="" width="100" height="100" srcset="https://citycamp.govfresh.com/files/2010/08/CityCamp5121-100x100.png 100w, https://citycamp.govfresh.com/files/2010/08/CityCamp5121-75x75.png 75w, https://citycamp.govfresh.com/files/2010/08/CityCamp5121.png 144w" sizes="(max-width: 100px) 100vw, 100px" />](http://citycamp.govfresh.com/files/2010/08/CityCamp5121.png)It started, almost a year ago, with a couple of tweets.  That&#8217;s when [Jennifer Pahlka](http://codeforamerica.org/who-we-are/ "Code for America") and I decided to organize a [barcamp](http://en.wikipedia.org/wiki/BarCamp) dedicated to [Gov 2.0](http://www.google.com/search?&q=what+is+gov+2.0) at the local level.  With absolutely zero forethought we decided that the time had come to take all of this talk about open data, participatory media, and &#8220;government as platform&#8221; to the places where citizens intersect government most directly and often:  the places in which we live.

Over the weekend of January 23 & 24, 115-or-so people came from across the U.S., Canada, and the U.K. to have earnest conversations about how to make municipal governments more open and user friendly.  We wanted to show local governments h0w to leverage the Web as a platform for building smarter local governments.  We wanted to understand the obstacles that stand in the way of this goal.

[CityCamp Chicago](http://barcamp.org/CityCamp-Original) was that inaugural event and it was a success beyond our expectations.  As we concluded the first CityCamp, we had no plans or expectations to carry on.  Our hope was that people would just copy what we did and have their own CityCamps.  In fact, [Washington, D.C. did just that](http://barcamp.org/CityCampDC).  But as time went on, I started getting calls and emails:  &#8220;Hey, when are you going to do a CityCamp in my city?&#8221;  Or, &#8220;We&#8217;re thinking about doing a CityCamp.  Can you help us out?&#8221;  That&#8217;s when I realized what had to be done.

Today I am thrilled, and admittedly a bit nervous, as we launch this online hub for CityCamp along with a CityCamp &#8220;world tour&#8221; that kicks off in [London](http://citycampldn.govfresh.com) this October 8-10.  I&#8217;m truly excited about this new web site, which is powered by [GovFresh](http://govfresh.com).