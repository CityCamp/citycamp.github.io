---
id: 6
title: Auto Draft
date: 2010-08-03T21:23:47-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/2010/08/03/5-revision/
permalink: /?p=6
---
