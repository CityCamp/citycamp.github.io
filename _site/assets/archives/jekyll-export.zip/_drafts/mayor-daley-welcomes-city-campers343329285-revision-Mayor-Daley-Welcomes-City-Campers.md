---
id: 448558436
title: Mayor Daley Welcomes City Campers!
date: 2010-01-19T18:37:00-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/343329285-revision/
permalink: /?p=448558436
---
[RMD Welcome Letter CityCamp Jan23,2010](http://www.scribd.com/doc/25449197/RMD-Welcome-Letter-CityCamp-Jan23-2010 "View RMD Welcome Letter CityCamp Jan23,2010 on Scribd")