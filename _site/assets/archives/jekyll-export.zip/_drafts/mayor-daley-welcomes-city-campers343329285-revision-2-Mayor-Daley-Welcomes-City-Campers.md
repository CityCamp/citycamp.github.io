---
id: 448558437
title: Mayor Daley Welcomes City Campers!
date: 2010-08-05T20:00:04-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/343329285-revision-2/
permalink: /?p=448558437
---
[RMD Welcome Letter CityCamp Jan23,2010](http://www.scribd.com/doc/25449197/RMD-Welcome-Letter-CityCamp-Jan23-2010 "View RMD Welcome Letter CityCamp Jan23,2010 on Scribd")