---
id: 448558487
title: Mayor Daley Welcomes City Campers!
date: 2010-08-05T20:31:15-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/343329285-revision-4/
permalink: /?p=448558487
---
[RMD Welcome Letter CityCamp Jan23,2010](http://www.scribd.com/doc/25449197/RMD-Welcome-Letter-CityCamp-Jan23-2010 "View RMD Welcome Letter CityCamp Jan23,2010 on Scribd")