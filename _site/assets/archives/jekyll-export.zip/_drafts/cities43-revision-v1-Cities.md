---
id: 448559366
title: Cities
date: 2013-10-28T08:15:51-05:00
author: Steven Clift
layout: revision
guid: http://citycamp.govfresh.com/43-revision-v1/
permalink: /?p=448559366
---
  
<small>View <a style="color: #0000ff; text-align: left;" href="http://maps.google.com/maps/ms?msa=0&msid=200211073035932406378.00049db1b90fd8f3be01d&ie=UTF8&ll=37.402882,-50.765523&spn=45.108447,214.106568&t=h&vpsrc=1&source=embed">CityCamp</a> in a larger map</small>

  1. _[Arizona](http://www.citycampaz.com/ "citycampaz.com")_, Chandler, Phoenix, Tuscon, USA
  2. [**Brighton**](http://citycampbtn.org/ "Brighton"), England, UK (2)
  3. [Buenos Aires](http://citycampba.com.ar/ "Buenos Aires"), Argentina
  4. [Chelmsford](http://citycampchelmsford.wordpress.com/ "Chelmsford"), England, UK
  5. [\*Chicago\*](http://barcamp.org/CityCamp-Original "barcamp wiki"), Illinois, USA (INAUGURAL CITYCAMP)
  6. _[**Colorado**](http://opencolorado.org/citycamp-colorado/ "home")_, Arvada, Boulder, Castle Rock, Denver, and Golden, USA (3)
  7. [Coventry, England, UK](http://citycampcov.org.uk/ "Coventry")
  8. <a title="Edmonton" href="http://citycampyeg.govfresh.com" target="_blank">Edmonton</a>, Alberta, Canada
  9. [_Hampton Roads_](http://citycamphrva.govfresh.com "Hampton Roads, Virginia"), Virginia
 10. [Honolulu](http://citycamphnl.govfresh.com "Honolulu"), Hawaii, USA
 11. [Kansas City](http://citycampkc.org "Kansas City"), Missouri, USA
 12. [London](http://citycampldn.govfresh.com "London"), England, UK
 13. [**Madison**](http://citycamp.barcampmadison.org/ "Madison"), Wisconsin, USA (2)
 14. [Manchester](http://citycampmcr.pbworks.com/w/page/35662383/FrontPage "Manchester"), England, UK
 15. [Minneapolis](http://citycampmn.org "Minneapolis"), Minnesota, USA
 16. [Monterrey](http://citycampmty.com/ "Monterrey"), Mexico
 17. [Oakland](http://citycampoak.org/), California, USA
 18. [Oklahoma City](http://gov20a.com), Oklahoma, USA
 19. [Perm](http://perm.citycamp.tv/ "Perm"), Russia
 20. [Raleigh](http://citycampral.org/ "Raleigh"), North Carolina, USA
 21. [**San Francisco**](http://citycampsf.govfresh.com/ "San Francisco"), California, USA (2)
 22. [Santiago](http://citycamp.cl/ "Santiago"), Chile
 23. [St. Petersburg](http://citycamp.tv "St. Petersburg"), Russia
 24. [_Tunisia_](http://www.citycamptunisia.org/ "Tunisia"), Bizerte, Sfax and Gafsa
 25. [Ulyanovsk](http://ul.citycamp.tv/ "Ulyanovsk"), Russia
 26. [Washington, D.C.](http://barcamp.org/CityCampDC "Washington, D.C. wiki"), USA

* City has a Web presence and community but has not yet held a camp.  
**bold** City has hosted more than one camp.  
_ital_ Multi-city or regional camp.

[Twitter accounts](http://twitter.com/citycamp/cities "@CityCamp")

[Delicious Catalog of Camps](http://www.delicious.com/tag/CityCamp+camp)

[Check the wiki](http://barcamp.org/CityCamp "wiki") in case people have added camps that have not been updated here.