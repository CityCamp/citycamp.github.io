---
id: 448558555
title: CityCamp 2.0
date: 2010-08-07T19:07:09-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558553-revision-2/
permalink: /?p=448558555
---
Eight months ago it started with a tweet.