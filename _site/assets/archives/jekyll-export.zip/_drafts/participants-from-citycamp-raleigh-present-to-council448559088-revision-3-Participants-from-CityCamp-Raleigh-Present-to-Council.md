---
id: 448559091
title: Participants from CityCamp Raleigh Present to Council
date: 2011-07-05T19:12:46-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559088-revision-3/
permalink: /?p=448559091
---
Members of &#8220;Team Open It Up&#8221; tell Raleigh City Council how they solved on Sunday a problem that was presented on Friday.