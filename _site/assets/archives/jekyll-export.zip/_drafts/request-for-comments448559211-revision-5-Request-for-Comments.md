---
id: 448559216
title: Request for Comments
date: 2011-11-21T18:35:04-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559211-revision-5/
permalink: /?p=448559216
---
<a style="font-weight: bold; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; text-align: center; background-color: #eeeeee;" href="http://en.wikipedia.org/wiki/Open_data"><img loading="lazy" style="border-style: initial; border-color: initial; margin-top: 5px !important; margin-right: auto !important; margin-bottom: 0px !important; margin-left: auto !important; display: block; max-width: 98%; border-width: 0px; padding: 0px;" title="Open Data Labels" src="http://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Open_Data_stickers.jpg/320px-Open_Data_stickers.jpg" alt="Open Data Labels" width="320" height="240" /></a>

<div>
  <a title="CityCampSF" href="http://citycampsf.govfresh.com" target="_blank">CityCampSF</a> organizer Adriel Hampton is working legislation to come up with a legal</p> 
  
  <div class="mceTemp">
    <dl id="" class="wp-caption alignright" style="width: 330px;">
      <dt class="wp-caption-dt">
      </dt>
      
      <dd class="wp-caption-dd">
        source: Wikipedia
      </dd>
    </dl>
  </div>
  
  <p>
    definition of open data in California. The definition will be used as a test for a requirement for the government to publish according to the definition. Note Adriel&#8217;s comments in the discussion. He specifically has been asked to address phrase like &#8220;commonly used Web search applications and commonly used software.&#8221; Also, there is a challenge to the no-cost claim. Please lend your expertise by commenting here.
  </p>
</div>

<a href="http://www.wiredtoshare.com/briefing_doc_structured_open_data_sf_ca" target="_blank">http://www.wiredtoshare.com/<wbr>briefing_doc_structured_open_<wbr>data_sf_ca</wbr></wbr></a>