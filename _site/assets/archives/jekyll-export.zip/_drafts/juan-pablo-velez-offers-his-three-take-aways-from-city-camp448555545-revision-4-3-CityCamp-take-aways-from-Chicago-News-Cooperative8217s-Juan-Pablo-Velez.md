---
id: 448558508
title: '3 CityCamp take-aways from Chicago News Cooperative&#8217;s Juan-Pablo Velez'
date: 2010-08-05T23:44:45-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448555545-revision-4/
permalink: /?p=448558508
---
