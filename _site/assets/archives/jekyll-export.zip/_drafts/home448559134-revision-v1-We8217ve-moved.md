---
id: 448559381
title: 'We&#8217;ve moved!'
date: 2014-10-05T17:18:19-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448559134-revision-v1/
permalink: /?p=448559381
---
The new CityCamp website is located at [citycamp.github.io](http://citycamp.github.io).