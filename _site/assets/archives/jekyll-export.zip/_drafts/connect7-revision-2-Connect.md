---
id: 15
title: Connect
date: 2010-08-03T21:24:01-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/2010/08/03/7-revision-2/
permalink: /?p=15
---
