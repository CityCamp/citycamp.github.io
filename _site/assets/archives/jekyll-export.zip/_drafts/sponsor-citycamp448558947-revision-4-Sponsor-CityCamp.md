---
id: 448558951
title: Sponsor CityCamp
date: 2011-03-14T19:57:49-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558947-revision-4/
permalink: /?p=448558951
---
I&#8217;m glad to report that we&#8217;ve rolled out means to direct financial and in-kind support to local organizers. Thanks (again) to <a title="about" href="http://forums.e-democracy.org/about/" target="_blank">e-democracy.org</a>, CityCamp now has a registered 501.3 (c) not-for-profit fiscal agent. The recently published [Sponsor Prospectus](https://docs.google.com/document/d/1pjbDoSZMit8ESJMbXZQGnJnGpqO-AqV7MBRFwRNUaAM/edit?hl=en) provides overview and details for how individuals, companies, and non-profits can make direct, tax-deductible contributions