---
id: 448558536
title: Welcome to CityCamp!
date: 2010-08-06T22:15:43-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-autosave/
permalink: /?p=448558536
---
CityCamp is an unconference focused on innovation for municipal governments and community organizations.