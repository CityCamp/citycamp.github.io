---
id: 448558807
title: CityCamp One Year Later
date: 2011-01-23T11:58:38-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558804-revision-3/
permalink: /?p=448558807
---
Today marks one year since [the first CityCamp](barcamp.org/CityCamp-Original "barcamp wiki") in Chicago, Illinois.  As is customary, we