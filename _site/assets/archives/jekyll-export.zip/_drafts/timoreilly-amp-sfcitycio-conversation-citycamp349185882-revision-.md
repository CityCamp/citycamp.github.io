---
id: 448558484
date: 2010-01-23T11:44:00-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/349185882-revision/
permalink: /?p=448558484
---
![](http://citycamp.us/photo/1280/349185882/1/tumblr_kwpl5cvE7Y1qaim46)

@timoreilly & @SFCityCIO conversation @CityCamp