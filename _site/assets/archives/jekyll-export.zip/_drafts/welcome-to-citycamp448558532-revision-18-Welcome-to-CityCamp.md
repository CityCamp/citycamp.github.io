---
id: 448558878
title: Welcome to CityCamp!
date: 2010-08-07T00:13:30-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-18/
permalink: /?p=448558878
---
CityCamp is an unconference focused on innovation for municipal governments and community organizations. [Learn more &raquo;](http://citycamp.govfresh.com/about/)