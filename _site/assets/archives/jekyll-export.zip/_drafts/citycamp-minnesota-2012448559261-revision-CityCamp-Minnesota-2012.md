---
id: 448559262
title: CityCamp Minnesota 2012
date: 2011-12-28T23:16:42-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559261-revision/
permalink: /?p=448559262
---
Reposted from <a title="CityCamp MN home" href="http://citycampmn.govfresh.com" target="_blank">CityCampMN</a>

_On November 12 we held the [1st CityCamp in Minnesota](http://citycampmn.org/)! _

_**On [Wednesday, January 11th](http://citycampmnjan112012.eventbrite.com/), the networking continues at [The Republic in Seven Corners](http://republicmn.com/) ****&#8211; **the same location as our post- CityCampMN happy hour._

**>> [RSVP HERE](http://citycampmnjan112012.eventbrite.com/) <<**