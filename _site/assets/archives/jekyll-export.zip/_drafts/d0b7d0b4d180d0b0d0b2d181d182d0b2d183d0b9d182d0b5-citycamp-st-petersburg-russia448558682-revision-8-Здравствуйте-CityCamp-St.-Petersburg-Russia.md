---
id: 448558695
title: Здравствуйте CityCamp St. Petersburg, Russia
date: 2010-09-10T20:28:33-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558682-revision-8/
permalink: /?p=448558695
---
Through the gift of Google Translate, we give you [CityCampSPb](http://twittter.com/CityCampSPb):

_&#8220;In the 20 century we have done everything to accommodate a city car, now needs to be done so that it becomes convenient for people&#8217;s lives. The problems of the city &#8211; it is our problem, the potential of the city &#8211; our potential._

_CityCamp &#8211; this anti-conference on innovation for the city. We will invite local authorities, representatives of the Administration of the city, famous people, programmers, and it-Schnick, designers, active citizens, bloggers, so they can share ideas, concerns, visions and perspectives. At the conference we will discuss and create solutions that can be used in cities to improve the lives of people of the city, using as a basis for open information technology and the Internet.&#8221;_

[<img loading="lazy" class="aligncenter size-medium wp-image-448558692" title="CityCampSPb" src="http://citycamp.govfresh.com/files/2010/09/CityCampSPb-550x78.jpg" alt="citycamp.tv" width="550" height="78" />](http://citycamp.tv)