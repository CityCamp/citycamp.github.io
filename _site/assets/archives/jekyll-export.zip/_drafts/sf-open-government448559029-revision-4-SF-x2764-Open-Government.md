---
id: 448559033
title: 'SF &#x2764; Open Government'
date: 2011-06-15T16:24:22-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559029-revision-4/
permalink: /?p=448559033
---
<div style="width: 465px" class="wp-caption aligncenter">
  <a href="http://sf.govfresh.com/govfresh-guide-to-sfopen-2011/"><img loading="lazy" class=" " title="SF Open 2011" src="http://sf.govfresh.com/files/2011/06/sfopen2011post.png" alt="SF Open 211" width="455" height="175" /></a>
  
  <p class="wp-caption-text">
    On Thursday, June 16th, Candidates for Mayor of San Francisco discuss the role open government for their city in a public forum produced by GovFresh
  </p>
</div>

&nbsp;

<p style="text-align: center;">
  <div style="width: 574px" class="wp-caption aligncenter">
    <a href="http://citycampsf.govfresh.com"><img loading="lazy" class=" " title="CityCamp SF" src="http://citycampsf.govfresh.com/files/2011/02/citycampsfheader4.png" alt="CityCamp San Francisco" width="564" height="119" /></a>
    
    <p class="wp-caption-text">
      On Saturday, June 18th, San Francisco will be the first city to host its 2nd CityCamp
    </p>
  </div>