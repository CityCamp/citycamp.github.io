---
id: 448558431
title: 'Tim O’Reilly’s brainstorm session at #CityCamp &#8211; “What Makes a Great City?” via Peter Corbett, iStrategyLabs'
date: 2010-08-05T19:51:29-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/355254130-revision-4/
permalink: /?p=448558431
---
[What Makes a Great City &#8211; #CityCamp Session led by @timoreilly](http://vimeo.com/8951498) from [Peter Corbett](http://vimeo.com/user1065288) on [Vimeo](http://vimeo.com).