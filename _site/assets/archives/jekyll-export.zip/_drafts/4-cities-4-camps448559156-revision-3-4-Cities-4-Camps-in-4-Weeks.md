---
id: 448559160
title: 4 Cities, 4 Camps in 4 Weeks
date: 2011-10-13T14:21:22-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559156-revision-3/
permalink: /?p=448559160
---
[<img loading="lazy" alt="Honolulu" src="http://citycamphnl.govfresh.com/wp-content/themes/cchnl/images/logo.png" title="HNL" class="alignnone" width="1000" height="120" />](http://citycamphnl.govfresh.com)Take a look at the calendar and you will see that four CityCamps will be hosted in four cities over the next four weeks: