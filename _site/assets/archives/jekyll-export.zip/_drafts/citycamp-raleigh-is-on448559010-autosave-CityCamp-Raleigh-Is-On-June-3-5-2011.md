---
id: 448559024
title: CityCamp Raleigh Is On June 3-5, 2011!
date: 2011-05-05T23:03:37-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559010-autosave/
permalink: /?p=448559024
---
## _Raleigh citizens creating solutions for open government_

_[<img loading="lazy" class="aligncenter size-medium wp-image-448559023" title="home_raleigh2" src="http://citycamp.govfresh.com/files/2011/05/home_raleigh21-545x500.png" alt="" width="545" height="500" srcset="https://citycamp.govfresh.com/files/2011/05/home_raleigh21-545x500.png 545w, https://citycamp.govfresh.com/files/2011/05/home_raleigh21-768x704.png 768w, https://citycamp.govfresh.com/files/2011/05/home_raleigh21-654x600.png 654w, https://citycamp.govfresh.com/files/2011/05/home_raleigh21.png 1050w" sizes="(max-width: 545px) 100vw, 545px" />](http://citycampral.org)  
_ 

_CityCamp Raleigh is three days of open sourced talks, workshops, and hands-on  problem solving, to re-imagine the way the web, applications, technology, and participation will shape the future of Raleigh._

_CityCamp brings together government, business, neighborhood, non-profit, and academic communities to work toward next generation solutions for Raleigh. You don’t need to be technical either–we need ideas from a variety of participants to help create solutions._

_The purpose is to highlight the power of participation, promote open source in local government, and explore how technology is used to increase government transparency. CityCamp Raleigh will foster communities of practice and create outcomes for participants both during, and after the event._

_We’ll be hearing inside views of the city from local leaders and getting inspiration from experts on social innovation and open data, before a participatory barcamp to discuss problems and new ideas, and finally ,a work day to see what solutions we can create._

_We want to collaborate and create the next generation of government using community-based solutions. CityCamp Raleigh is how open government, “Gov 2.0,” goes local–and you can join the movement._

_[Get involved here.](http://citycampral.org/get-involved/ "citycampral.org")_

&nbsp;