---
id: 448558652
title: Start a Camp
date: 2010-08-17T22:48:36-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558491-revision-8/
permalink: /?p=448558652
---
Thinking about starting a CityCamp where you live?  Great!  We&#8217;re working on the tools to help you do that.

In the meantime, use this form to contact us for help starting a CityCamp where you live:

[contact-form 1 &#8220;Contact form 1&#8221;]

Here is a list of some of the typical responsibilities of a host:

  1. Establish Scope and Theme
  2. Book a Venue
  3. Establish a Web Presence
  4. Solicit Sponsorship (if needed)
  5. Invite Participants
  6. Cater Your Event