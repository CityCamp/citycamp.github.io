---
id: 448558615
title: CityCampLDN set for Oct. 8-10
date: 2010-08-11T17:30:55-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558600-revision-14/
permalink: /?p=448558615
---
The CityCamp World Tour kicks off in London at [CityCampLDN](http://citycampldn.govfresh.com/), October 8-10. [See the official site for complete details.](http://citycampldn.govfresh.com) You can also follow on Twitter at @[CityCampLDN](http://twitter.com/CityCampLDN).

[<img loading="lazy" src="http://citycamp.govfresh.com/files/2010/08/Picture-11-550x318.png" alt="CityCampLDN" title="CityCampLDN" width="550" height="318" class="alignnone size-medium wp-image-448558606" srcset="https://citycamp.govfresh.com/files/2010/08/Picture-11-550x318.png 550w, https://citycamp.govfresh.com/files/2010/08/Picture-11-768x444.png 768w, https://citycamp.govfresh.com/files/2010/08/Picture-11-900x521.png 900w, https://citycamp.govfresh.com/files/2010/08/Picture-11.png 1025w" sizes="(max-width: 550px) 100vw, 550px" />](http://citycampldn.govfresh.com)