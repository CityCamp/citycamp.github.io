---
id: 448558466
title: '&#8220;How our unconference worked&#8221; by Steven Clift, e-democracy.org'
date: 2010-02-19T23:56:19-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/399903622-revision/
permalink: /?p=448558466
---
[youtube=]