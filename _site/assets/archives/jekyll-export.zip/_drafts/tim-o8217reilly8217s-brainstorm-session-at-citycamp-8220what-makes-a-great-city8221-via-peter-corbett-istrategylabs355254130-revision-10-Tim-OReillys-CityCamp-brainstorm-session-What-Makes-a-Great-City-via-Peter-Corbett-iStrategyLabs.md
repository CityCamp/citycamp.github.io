---
id: 448558473
title: Tim O’Reilly’s CityCamp brainstorm session “What Makes a Great City?” via Peter Corbett, iStrategyLabs
date: 2010-08-05T23:22:54-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/355254130-revision-10/
permalink: /?p=448558473
---
