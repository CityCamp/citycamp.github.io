---
id: 448559367
title: About
date: 2011-05-03T23:16:31-05:00
author: Steven Clift
layout: revision
guid: http://citycamp.govfresh.com/2-revision-v1/
permalink: /?p=448559367
---
## What is CityCamp?

CityCamp is an [unconference](http://en.wikipedia.org/wiki/Unconference "wikipedia") focused on innovation for municipal governments and community organizations.  As an unconference, content for CityCamp is not programmed for a passive audience.  Instead, content is created and organized by participants and coordinated by facilitators.  Participants are expected to play active roles in sessions.  This provides an excellent format for creative, open exchange geared toward action.

[The first CityCamp](http://barcamp.pbworks.com/CityCamp-Original) was held in Chicago, Illinois, 23-24 January, 2010. CityCamp is inspired by [Transparency Camp](http://transparencycamp.org/) and [Gov 2.0 Camp](http://barcamp.pbworks.com/Government20Camp). Visit the [CityCamp Wiki](http://barcamp.org/CityCamp) for details.

## Stimulate, Participate, Collaborate, Repeat

Each City Camp has four main goals:

  1. Bring together local government officials, municipal employees, experts, programmers, designers, citizens and journalists to share perspectives and insights about the cities in which they live
  2. Create and maintain patterns for using the Web to facilitate local government transparency and effective local governance
  3. Foster communities of practice and advocacy on the role of the Web, mobile communication, online information, and open data in cities
  4. Create outcomes that participants will act upon after the event is over

CityCamp explores and documents ideas, lessons learned, best practices, and patterns that can be implemented within and shared across municipalities, anywhere in the world.  Of particular interest is the use of social/participatory media, mobile devices, linked open data, and &#8220;[Web as platform](http://oreilly.com/web2/archive/what-is-web-20.html "What is Web 2.0?").”

CityCamp recognizes that local governments and community organizations have the most direct influence and impact on our daily lives.  This event seeks to create local communities of practice who are dedicated to design, process, and technology applications that make cities and other local communities more open and “user friendly”<a name="brand"></a>.

## Open Source Brand

[CityCamp is an &#8220;open source brand&#8221; that exists in the Creative Commons](http://citycamp.govfresh.com/license).  Open source ensures that CityCamp is maintained as a pattern that is easily repeatable and for anyone to use.  Branding ensures that the pattern is recognizable and that independent organizers don’t misrepresent CityCamp. No one organization will own CityCamp.  Instead it will be maintained by the CityCamp community supported by a cadre of local community organizers.

## Funding & Support

<span style="font-weight: normal; font-size: 13px;">CityCamp events are funded and supported by <a title="barcamp wiki" href="http://barcamp.org/CityCamp-Sponsors">sponsoring businesses and non-profit organizations</a>, grants, donations, and volunteers.</span>

<span style="font-weight: normal; font-size: 13px;">The fiscal agent for CityCamp is <a title="about e-democracy.org" href="http://e-democracy.org/about">e-democracy.org</a>.  E-Democracy.org is officially &#8220;Minnesota E-Democracy&#8221; and a registered 501c.3 non-profit organization based in the United States. Contributions are tax deductible in the United States. Check your local tax laws to determine deductible status in other countries.</span>

<span style="font-weight: normal; font-size: 13px;"><a title="PayPal.com" href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CAUR9XZNE5R5U">Click to Contribute via PayPal</a>.</span>

Please visit this page for more information about and options for supporting CityCamp with your financial contributions:  
<http://forums.e-democracy.org/about/citycamp/>

_CityCamp is a non-partisan, non-political activity and organization_