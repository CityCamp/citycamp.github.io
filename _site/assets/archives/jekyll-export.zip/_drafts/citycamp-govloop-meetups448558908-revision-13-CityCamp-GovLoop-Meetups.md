---
id: 448558921
title: CityCamp-GovLoop Meetups
date: 2011-03-02T20:17:00-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558908-revision-13/
permalink: /?p=448558921
---
We&#8217;ve been hosting meetups all over. Some cities are recapping what&#8217;s happened locally since their camp