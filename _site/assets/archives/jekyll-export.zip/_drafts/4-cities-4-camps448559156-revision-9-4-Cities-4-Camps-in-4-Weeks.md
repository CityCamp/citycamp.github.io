---
id: 448559166
title: 4 Cities, 4 Camps in 4 Weeks
date: 2011-10-13T14:32:05-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559156-revision-9/
permalink: /?p=448559166
---
Take a look at the calendar and you will see that four CityCamps will be hosted in four cities over the next four weeks:



## October 14: Manchester, UK

[<img loading="lazy" class="alignnone" title="MCR" src="http://a3.twimg.com/profile_images/1227140564/ccMCR_logo.jpg" alt="Manchester" width="180" height="180" />](http://citycampmcr.org)

## October 28: Colorado (2nd CityCamp)

[<img loading="lazy" class="alignnone" title="CO" src="http://evbdn.eventbrite.com/s3-s3/eventlogos/3213920/1888152515-1.png" alt="Colorado" width="300" height="52" />](http://opencolorado.org/citycamp-colorado/)

## November 12: Minnesota

[<img loading="lazy" class="alignnone" title="MN" src="http://citycampmn.govfresh.com/wp-content/themes/cchmn/images/logo.png" alt="Minnesota" width="1000" height="120" />](http://citycampmn.govfresh.com)

## December 3: Honolulu

[<img loading="lazy" class="alignnone" title="HNL" src="http://citycamphnl.govfresh.com/wp-content/themes/cchnl/images/logo.png" alt="Honolulu" width="1000" height="120" />](http://citycamphnl.govfresh.com)

Not bad for a &#8220;leaderless movement.&#8221;