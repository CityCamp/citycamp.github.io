---
id: 448558859
title: CityCamp Arizona Next Week
date: 2011-02-08T20:39:35-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558857-revision/
permalink: /?p=448558859
---
[<img loading="lazy" class="size-medium wp-image-448558858 alignleft" title="CityCamp Arizona" src="http://citycamp.govfresh.com/files/2011/02/citycampaz-550x197.png" alt="CityCamp Arizona" width="550" height="197" />](http://citycamp.govfresh.com/files/2011/02/citycampaz.png)CityCamp Arizona is next week, Tuesday, February 15th in the [City of Chandler](http://www.chandleraz.gov/ "chandleraz.gov").

_[CityCamp](http://citycamp.com/ "CityCamp home") Arizona will bring together people like yourself to share ideas to improve local government. CityCamp is an unconference focused toward the participants sharing insights and experiences and taking action to bring about the significant, positive change our communities need. At an unconference, content is created and organized by participants. This format provides an excellent opportunity for an active, creative, open exchange geared toward action. Afterall, innovation is only possible when good ideas are shared and well executed._

CityCamp AZ is organized by