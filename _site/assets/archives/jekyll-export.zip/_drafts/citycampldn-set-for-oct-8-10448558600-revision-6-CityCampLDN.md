---
id: 448558607
title: CityCampLDN
date: 2010-08-11T17:24:38-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558600-revision-6/
permalink: /?p=448558607
---
The CityCamp World Tour will kick off at [CityCampLDN](http://citycampldn.govfresh.com/), on Twitter at @[CityCampLDN](http://twitter.com/CityCampLDN)