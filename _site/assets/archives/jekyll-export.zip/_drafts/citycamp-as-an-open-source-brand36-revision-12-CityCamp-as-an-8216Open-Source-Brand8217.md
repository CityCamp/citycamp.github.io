---
id: 448558489
title: 'CityCamp as an &#8216;Open Source Brand&#8217;'
date: 2010-08-05T23:55:14-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/36-revision-12/
permalink: /?p=448558489
---
We&#8217;re working on making CityCamp an &#8220;open source brand.&#8221;  [CityCamp should exist in the Creative Commons](http://citycamp.govfresh.com/license/).  Open source ensures that CityCamp is maintained as a pattern that is easily repeatable and for anyone to use.  Branding ensures that the pattern is recognizable and that independent organizers don’t misrepresent CityCamp. No one organization will own CityCamp.  Instead it will be maintained by the CityCamp community supported by a cadre of local community organizers.