---
id: 448559035
title: 'SF &#x2764; Open Government'
date: 2011-06-15T16:37:28-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559029-revision-6/
permalink: /?p=448559035
---
Tomorrow is the first of two important events happening in San Francisco. From 5:30 &#8211; 7:30 PM Pacific time, [SF Open 2011](http://sf.govfresh.com/govfresh-guide-to-sfopen-2011/ "sfopen.govfresh.com") will:

> bring together the 2011 San Francisco Mayoral candidates for a discussion on open government, civic engagement, technology and innovation. Participating candidates include Michela Alioto-Pier, John Avalos, David Chiu, Bevan Dufty, Tony Hall, Dennis Herrera, Joanna Rees, Phil Ting and Leland Yee and will be moderated by Mitch Kapor. The event will be held June 16 at Automattic (registration). SFOpen 2011 serves as the kick-off for San Francisco’s Summer of Smart, “a four-month experiment in urban innovation and open government.”

<div style="width: 465px" class="wp-caption aligncenter">
  <a href="http://sf.govfresh.com/govfresh-guide-to-sfopen-2011/"><img loading="lazy" class=" " title="SF Open 2011" src="http://sf.govfresh.com/files/2011/06/sfopen2011post.png" alt="SF Open 211" width="455" height="175" /></a>
  
  <p class="wp-caption-text">
    On Thursday, June 16th, Candidates for Mayor of San Francisco discuss the role open government for their city in a public forum produced by GovFresh
  </p>
</div>

<p style="text-align: left;">
  Two days later, <a title="citycampsf.govfresh.com" href="http://citycampsf.govfresh.com">CityCampSF</a> will make San Francisco the first city to host a second CityCamp unconference. The <a title="eventbrite" href="http://ccsf2011.eventbrite.com/">list of registered participants</a> is amazing. Several city employees are signed up, as are some of the mayoral candidates.
</p>

<div style="width: 574px" class="wp-caption aligncenter">
  <a href="http://citycampsf.govfresh.com"><img loading="lazy" class=" " title="CityCamp SF" src="http://citycampsf.govfresh.com/files/2011/02/citycampsfheader4.png" alt="CityCamp San Francisco" width="564" height="119" /></a>
  
  <p class="wp-caption-text">
    On Saturday, June 18th, San Francisco will be the first city to host its 2nd CityCamp
  </p>
</div>

You can follow all of this local open gov action online:

<a title="twitter search" href="http://search.twitter.com/search?q=sfopen" target="_blank">#sfopen</a>

<a title="livestream" href="http://summerofsmart.org/live" target="_blank">summerofsmart.org/live</a>

<a title="twitter search" href="http://search.twitter.com/search?q=citycampsf" target="_blank">#citycampsf</a>

&nbsp;