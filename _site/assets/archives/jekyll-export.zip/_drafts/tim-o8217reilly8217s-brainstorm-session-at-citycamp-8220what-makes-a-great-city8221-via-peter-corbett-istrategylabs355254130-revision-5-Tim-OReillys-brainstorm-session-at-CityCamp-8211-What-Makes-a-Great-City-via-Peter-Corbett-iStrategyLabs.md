---
id: 448558432
title: 'Tim O’Reilly’s brainstorm session at #CityCamp &#8211; “What Makes a Great City?” via Peter Corbett, iStrategyLabs'
date: 2010-08-05T19:51:38-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/355254130-revision-5/
permalink: /?p=448558432
---
<object width=&#8221;640&#8243; height=&#8221;360&#8243;><param name=&#8221;allowfullscreen&#8221; value=&#8221;true&#8221; /><param name=&#8221;allowscriptaccess&#8221; value=&#8221;always&#8221; /><param name=&#8221;movie&#8221; value=&#8221;http://vimeo.com/moogaloop.swf?clip\_id=8951498&server=vimeo.com&show\_title=1&show\_byline=1&show\_portrait=1&color=FF7700&fullscreen=1&autoplay=0&loop=0&#8243; /><embed src=&#8221;http://vimeo.com/moogaloop.swf?clip\_id=8951498&server=vimeo.com&show\_title=1&show\_byline=1&show\_portrait=1&color=FF7700&fullscreen=1&autoplay=0&loop=0&#8243; type=&#8221;application/x-shockwave-flash&#8221; allowfullscreen=&#8221;true&#8221; allowscriptaccess=&#8221;always&#8221; width=&#8221;640&#8243; height=&#8221;360&#8243;></embed></object><p><a href=&#8221;http://vimeo.com/8951498&#8243;>What Makes a Great City &#8211; #CityCamp Session led by @timoreilly</a> from <a href=&#8221;http://vimeo.com/user1065288&#8243;>Peter Corbett</a> on <a href=&#8221;http://vimeo.com&#8221;>Vimeo</a>.</p>