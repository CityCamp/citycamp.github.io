---
id: 448558544
title: Welcome to CityCamp!
date: 2010-08-06T22:17:22-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558532-revision-9/
permalink: /?p=448558544
---
CityCamp is an unconference focused on innovation for municipal governments and community organizations.