---
id: 448558605
title: CityCampLDN
date: 2010-08-11T17:24:32-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558600-revision-5/
permalink: /?p=448558605
---
The CityCamp World Tour will kick off at [CityCampLDN](http://citycampldn.govfresh.com/), on Twitter at @[CityCampLDN](http://twitter.com/CityCampLDN)