---
id: 448558591
title: CityCamp gets GovFresh
date: 2010-08-11T12:29:39-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558590-revision/
permalink: /?p=448558591
---
