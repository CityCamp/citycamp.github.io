---
id: 448559093
title: Participants from CityCamp Raleigh Present to Council
date: 2011-07-05T19:19:15-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559088-autosave/
permalink: /?p=448559093
---
Members of &#8220;[Team Open It Up](http://ncopendata.org "ncopendata.org")&#8221; tell [Raleigh City Council](http://raleigh.granicus.com/MediaPlayer.php?view_id=21&clip_id=2157 "full meeting archive") how they used Sunday to solve a problem that was presented on Friday.