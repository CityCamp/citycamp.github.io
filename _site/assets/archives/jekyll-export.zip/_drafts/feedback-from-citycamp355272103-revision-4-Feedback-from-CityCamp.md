---
id: 448558448
title: 'Feedback from #CityCamp'
date: 2010-08-05T20:10:24-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/355272103-revision-4/
permalink: /?p=448558448
---
