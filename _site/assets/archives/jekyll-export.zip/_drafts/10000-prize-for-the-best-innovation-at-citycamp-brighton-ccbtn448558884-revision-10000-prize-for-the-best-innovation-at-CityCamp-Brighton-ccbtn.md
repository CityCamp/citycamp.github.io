---
id: 448558885
title: '£10,000 prize for the best innovation at CityCamp Brighton #ccbtn'
date: 2011-02-12T22:25:40-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558884-revision/
permalink: /?p=448558885
---
CityCamp Brighton announced that:

> one of our amazing sponsors, the [Aldridge Foundation](http://www.aldridgefoundation.com/), has agreed to put up a **ten thousand pound prize fund** to implement the best innovation we create at CityCamp.
> 
> We’re very pleased and proud that the Foundation has given us, and the city’s innovators, that level of commitment. Most of all we’re hugely excited to be able to turn some of the ambitions and ideas of CityCamp into real, delivered change.
> 
> The full details of the prize will be announced on the day, but it will take the form of a development fund to help the team behind the best idea work with the relevant public services over six months to deliver their vision.

There&#8217;s no point in waiting until the event. Start now