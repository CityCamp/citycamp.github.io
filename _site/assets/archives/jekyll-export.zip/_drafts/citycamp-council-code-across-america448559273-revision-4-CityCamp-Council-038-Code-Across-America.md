---
id: 448559277
title: 'CityCamp Council &#038; Code Across America'
date: 2012-02-11T21:01:48-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559273-revision-4/
permalink: /?p=448559277
---
## CityCamp Council

This coming Tuesday we&#8217;re having a kickoff meeting of organizers for the world CityCamp Council planned for this year. I&#8217;m stoked that we&#8217;ll have 12 participants that include representatives from all 4 countries where there have been CityCamps: US, UK, Russia, and Canada. Three members of the org team are from government.

## Code Across America

From 24 February through 4 March CityCampers, Open Gov-ers, Code for America fellows, and other civic-minded hackers will participate in a national week of civic innovation. We&#8217;ll deploy apps, liberate data, and share the skills we need to build a civic web.

<div>
  Look for an event near you:
</div>

<div>
  <br /><small>View <a href="http://maps.google.com/maps/ms?msa=0&msid=211836600249959492431.0004b7e101749ee348269&ie=UTF8&t=m&ll=31.952162,-116.367187&spn=95.273845,149.414063&z=2&source=embed" style="color:#0000FF;text-align:left">Code Across America</a> in a larger map</small>
</div>