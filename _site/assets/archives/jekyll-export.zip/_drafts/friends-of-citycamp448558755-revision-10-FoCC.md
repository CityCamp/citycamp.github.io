---
id: 448558769
title: FoCC
date: 2010-10-29T14:39:46-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558755-revision-10/
permalink: /?p=448558769
---
[](http://civiccommons.com/)

## (Friends of CityCamp)

[![Civic Commons](http://citycamp.govfresh.com/files/2010/10/civiccommons-logo-web-e1288269713206.png)](http://civiccommons.com/)

[](http://civiccommons.com/)  
[![Code for America](http://citycamp.govfresh.com/files/2010/10/codeforamerica-150x61.png)](http://codeforamerica.org/)

[](http://codeforamerica.org/)  
[![E-Democracy.org](http://citycamp.govfresh.com/files/2010/10/e-democracy300pxRGB-e1288269366216.png)](http://e-democracy.org/)

[](http://e-democracy.org/)  
[![Gov 2.0 Summit](http://citycamp.govfresh.com/files/2010/10/Gov2Summit-300x182-e1288270434373.gif "O’Reilly Media Event")](http://gov2summit.com/ "O’Reilly Media Event")

[](http://gov2summit.com/ "O’Reilly Media Event")  
[![GovFresh](http://citycamp.govfresh.com/files/2010/10/govfresh-e1288268660662.png)](http://govfresh.com/)

[](http://govfresh.com/)  
[![GovLoop](http://citycamp.govfresh.com/files/2010/10/govloop-e1288380763577.png)](http://govloop.com/)

[](http://govloop.com/)  
[![O'Reilly Media](http://citycamp.govfresh.com/files/2010/10/oralogo-e1288269153400.png "Spreading the knowledge of technology innovators")](http://www.oreilly.com/ "Spreading the knowledge of technology innovators")

[](http://www.oreilly.com/ "Spreading the knowledge of technology innovators")  
[![Sunlight Foundation](http://citycamp.govfresh.com/files/2010/10/sunlightlogowhite-e1288268543959.gif)](http://sunlightfoundation.com/)

[](http://sunlightfoundation.com/)  
[![The Rockefeller Foundation](http://citycamp.govfresh.com/files/2010/10/rockfound.png)](http://rockfound.org/)