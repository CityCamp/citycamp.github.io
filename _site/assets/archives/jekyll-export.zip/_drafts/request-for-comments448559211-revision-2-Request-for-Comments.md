---
id: 448559213
title: Request for Comments
date: 2011-11-21T18:29:35-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559211-revision-2/
permalink: /?p=448559213
---
<div>
  <a title="CityCampSF" href="http://citycampsf.govfresh.com" target="_blank">CityCampSF</a> is working legislation to come up with a legal definition of open data in California. The definition will be used as a test for a requirement for the government to publish according to the definition. Note his comments in the discussion. He specifically has been asked to address phrase like &#8220;commonly used Web search applications and commonly used software.&#8221; Also, there is a challenge to the no-cost claim. Please lend your expertise.
</div>

<a href="http://www.wiredtoshare.com/briefing_doc_structured_open_data_sf_ca" target="_blank">http://www.wiredtoshare.com/<wbr>briefing_doc_structured_open_<wbr>data_sf_ca</wbr></wbr></a>

<div>
</div>