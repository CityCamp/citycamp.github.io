---
id: 448559163
title: 4 Cities, 4 Camps in 4 Weeks
date: 2011-10-13T14:25:58-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559156-revision-6/
permalink: /?p=448559163
---
Take a look at the calendar and you will see that four CityCamps will be hosted in four cities over the next four weeks:



[<img loading="lazy" alt="Honolulu" src="http://citycamphnl.govfresh.com/wp-content/themes/cchnl/images/logo.png" title="HNL" class="alignnone" width="1000" height="120" />](http://citycamphnl.govfresh.com)

[<img loading="lazy" alt="Minnesota" src="http://citycampmn.govfresh.com/wp-content/themes/cchmn/images/logo.png" title="MN" class="alignnone" width="1000" height="120" />](http://citycampmn.govfresh.com)

[<img loading="lazy" alt="Colorado" src="http://evbdn.eventbrite.com/s3-s3/eventlogos/3213920/1888152515-1.png" title="CO" class="alignnone" width="350" height="62" />](http://opencolorado.org/citycamp-colorado/)

[<img loading="lazy" alt="Manchester" src="http://a3.twimg.com/profile_images/1227140564/ccMCR_logo.jpg" title="MCR" class="alignnone" width="235" height="235" />](http://citycampmcr.org)