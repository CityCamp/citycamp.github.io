---
id: 448558512
title: 'Tim O’Reilly’s CityCamp brainstorm session &#8216;What Makes a Great City?&#8217;'
date: 2010-08-05T23:23:16-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/355254130-revision-11/
permalink: /?p=448558512
---
