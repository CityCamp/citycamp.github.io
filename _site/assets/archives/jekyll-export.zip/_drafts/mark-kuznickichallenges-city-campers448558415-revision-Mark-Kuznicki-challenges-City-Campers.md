---
id: 448558416
title: Mark Kuznicki challenges City Campers
date: 2010-03-14T18:40:25-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558415-revision/
permalink: /?p=448558416
---
