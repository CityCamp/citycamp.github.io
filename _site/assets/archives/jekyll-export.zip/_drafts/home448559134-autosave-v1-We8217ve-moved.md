---
id: 448559378
title: 'We&#8217;ve moved!'
date: 2014-10-05T17:14:58-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448559134-autosave-v1/
permalink: /?p=448559378
---
CityCamp is an international unconference series and online community focused on innovation for municipal governments and community organizations.