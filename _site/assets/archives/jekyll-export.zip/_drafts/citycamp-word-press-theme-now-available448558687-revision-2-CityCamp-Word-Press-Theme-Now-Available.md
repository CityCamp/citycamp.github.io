---
id: 448558715
title: CityCamp Word Press Theme Now Available
date: 2010-09-12T18:00:14-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558687-revision-2/
permalink: /?p=448558715
---
We were serious when we said that CityCamp is an &#8220;open source brand.&#8221; We want to make it easy to stand up your own CityCamp site. One of the ways we can do that is by publishing ourWord Press theme:

<http://govfresh.com/wp-content/uploads/zip/citycamp.zip>

[Start-a-Camp](http://citycamp.govfresh.com/start-a-camp "start!")!