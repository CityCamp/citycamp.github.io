---
id: 448558594
title: CityCamp gets GovFresh
date: 2010-08-11T12:35:43-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558590-revision-4/
permalink: /?p=448558594
---
Welcome to the new CityCamp Website!

As part of our efforts to promote the CityCamp Word Tour, we&#8217;re working with [GovFresh](http://govfresh.com) to create this new hub for all things CityCamp. Don&#8217;t worry. There&#8217;s still an open [barcamp wiki](http://barcamp.org/CityCamp) and a [public forum](http://forums.e-democracy.org/groups/citycamp). This site brings it all together through a common portal with a great look and feel. In fact, our hope is that this site will help establish CityCamp as an &#8216;[open source brand](http://citycamp.govfresh.com/citycamp-as-an-open-source-brand/),&#8217; something that is both easily repeatable and recognizable for anyone to use. That&#8217;s why we put CityCamp in the Creative Commons. There will be a few rules to follow, but as few as possible. We haven&#8217;t completely worked out those details but didn&#8217;t want to wait to get started.