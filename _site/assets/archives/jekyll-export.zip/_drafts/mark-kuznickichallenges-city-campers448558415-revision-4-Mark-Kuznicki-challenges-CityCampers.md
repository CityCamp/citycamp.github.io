---
id: 448558507
title: Mark Kuznicki challenges CityCampers
date: 2010-08-05T23:44:21-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448558415-revision-4/
permalink: /?p=448558507
---
