---
id: 448558438
title: 'Feedback from #CityCamp'
date: 2010-01-26T20:51:23-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/355272103-revision/
permalink: /?p=448558438
---
[youtube=]