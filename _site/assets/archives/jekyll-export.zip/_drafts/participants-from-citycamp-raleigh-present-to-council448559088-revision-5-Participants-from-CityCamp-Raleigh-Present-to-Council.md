---
id: 448559094
title: Participants from CityCamp Raleigh Present to Council
date: 2011-07-05T19:13:47-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559088-revision-5/
permalink: /?p=448559094
---
Members of &#8220;[Team Open It Up](http://ncopendata.org "ncopendata.org")&#8221; tell Raleigh City Council how they solved on Sunday a problem that was presented on Friday.