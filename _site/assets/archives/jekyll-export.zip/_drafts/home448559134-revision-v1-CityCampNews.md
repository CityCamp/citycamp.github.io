---
id: 448559382
title: CityCampNews
date: 2014-10-27T23:08:50-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448559134-revision-v1/
permalink: /?p=448559382
---
