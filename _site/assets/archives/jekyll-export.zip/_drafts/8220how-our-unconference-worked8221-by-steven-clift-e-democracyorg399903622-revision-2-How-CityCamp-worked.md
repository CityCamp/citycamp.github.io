---
id: 448558509
title: How CityCamp worked
date: 2010-08-05T23:14:53-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/399903622-revision-2/
permalink: /?p=448558509
---
