---
id: 448558449
title: Mayor Daley Welcomes City Campers!
date: 2010-08-05T20:00:21-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/343329285-revision-3/
permalink: /?p=448558449
---
[RMD Welcome Letter CityCamp Jan23,2010](http://www.scribd.com/doc/25449197/RMD-Welcome-Letter-CityCamp-Jan23-2010 "View RMD Welcome Letter CityCamp Jan23,2010 on Scribd")