---
id: 448558808
title: CityCamp One Year Later
date: 2011-01-23T12:11:25-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558804-revision-4/
permalink: /?p=448558808
---
Today marks one year since [the first CityCamp](barcamp.org/CityCamp-Original "barcamp wiki") in Chicago, Illinois.  As is customary, it&#8217;s time to take time to reflect on what has transpired in the year since that fateful weekend.