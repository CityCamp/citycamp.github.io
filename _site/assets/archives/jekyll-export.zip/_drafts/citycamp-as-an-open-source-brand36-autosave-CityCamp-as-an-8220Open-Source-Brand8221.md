---
id: 46
title: 'CityCamp as an &#8220;Open Source Brand&#8221;'
date: 2010-08-05T20:33:01-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/36-autosave/
permalink: /?p=46
---
We&#8217;re working on making CityCamp an &#8220;open source brand.&#8221;  [CityCamp should exist in the Creative Commons](http://citycamp.govfresh.com/license/).  Open source ensures that CityCamp is maintained as a pattern that is easily repeatable and for anyone to use.  Branding ensures that the pattern is recognizable and that independent organizers don’t misrepresent CityCamp.   No one organization will own CityCamp.  Instead it will be maintained by the CityCamp community with the support of a cadre of local organizers.