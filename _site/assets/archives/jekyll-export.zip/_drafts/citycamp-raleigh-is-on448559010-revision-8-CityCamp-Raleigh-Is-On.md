---
id: 448559019
title: CityCamp Raleigh Is On!
date: 2011-05-04T10:38:58-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559010-revision-8/
permalink: /?p=448559019
---
## _Raleigh citizens creating solutions for open government_

## [<img loading="lazy" class="aligncenter size-medium wp-image-448559011" title="CityCamp Raleigh" src="http://citycamp.govfresh.com/files/2011/05/home_raleigh2-550x498.png" alt="click to visit http://citycampral.org" width="550" height="498" srcset="https://citycamp.govfresh.com/files/2011/05/home_raleigh2-550x498.png 550w, https://citycamp.govfresh.com/files/2011/05/home_raleigh2-661x600.png 661w, https://citycamp.govfresh.com/files/2011/05/home_raleigh2-400x362.png 400w, https://citycamp.govfresh.com/files/2011/05/home_raleigh2.png 1060w" sizes="(max-width: 550px) 100vw, 550px" />](http://citycampral.org)

_CityCamp Raleigh is three days of open sourced talks, workshops, and hands-on  problem solving, to re-imagine the way the web, applications, technology, and participation will shape the future of Raleigh._

_CityCamp brings together government, business, neighborhood, non-profit, and academic communities to work toward next generation solutions for Raleigh. You don’t need to be technical either–we need ideas from a variety of participants to help create solutions._

_The purpose is to highlight the power of participation, promote open source in local government, and explore how technology is used to increase government transparency. CityCamp Raleigh will foster communities of practice and create outcomes for participants both during, and after the event._

_We’ll be hearing inside views of the city from local leaders and getting inspiration from experts on social innovation and open data, before a participatory barcamp to discuss problems and new ideas, and finally ,a work day to see what solutions we can create._

_We want to collaborate and create the next generation of government using community-based solutions. CityCamp Raleigh is how open government, “Gov 2.0,” goes local–and you can join the movement._

_[Get involved here.](http://citycampral.org/get-involved/ "citycampral.org")_

&nbsp;