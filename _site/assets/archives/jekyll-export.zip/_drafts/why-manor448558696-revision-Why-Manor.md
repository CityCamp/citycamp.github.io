---
id: 448558697
title: Why Manor?
date: 2010-09-12T14:41:12-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558696-revision/
permalink: /?p=448558697
---
The other night I was chatting with [GovFresh](http://govfresh.com "home") founder Luke Fretwell about the upcoming [manor.govfresh](http://govfresh.com/manor "home") event, happening in Manor, TX in less than two weeks.  He asked me a simple, obvious question:  why am I going?  I gave him some reasons off the top of my head.  Eventually the conversation turned to other topics.  But it got me thinking more about the event and why it&#8217;s significant.

Last I checked there are about 30 government [attendees](http://manorgovfresh.eventbrite.com/ "eventbrite") signed up for manor.govfresh.  They represented about two-thirds as many _different_ government organizations.  Almost all of them are from local governments.

Part of manor.govfresh is also fascinating and worthwhile experiment in &#8220;making over&#8221; another small town in Texas called [DeLeon](http://www.deleontexas.com/ "home").  Imagine _[Extreme Home Makeover](http://abc.go.com/shows/extreme-makeover-home-edition "abc.com")_ for local government IT.  Try as they might, it seems nearly impossible for even willing governme nts to make the improvements everyone agrees are needed.  Budgets aren&#8217;t just tight.  They are disappearing.  99% of the time IT is a support function; not the mission itself.   So [Dustin Haisler](http://cityofmanor.org/wordpress/author/dhaisler/ "manor.org bio"), playing the part of (a subdued) [Ty Pennington](http://www.imdb.com/name/nm0672205/ "imdb") is showing with an expert team of Gov 2.0 implementers to give the deserving town of DeLeon the lift it needs to move into the online 21st century.

Manor.govfresh is different from CityCamp.

There was something special about the GovFresh event Luke put on in San Francisco, too.  At the end of the event San Francisco CIO Chris Vein took questions from the audience.  For about an hour he had an open dialog with his core constituency; the coders, journalists, designers, and community organizers who are interested in San Francisco&#8217;s open government initiatives.  Where else does that happen?  No where.