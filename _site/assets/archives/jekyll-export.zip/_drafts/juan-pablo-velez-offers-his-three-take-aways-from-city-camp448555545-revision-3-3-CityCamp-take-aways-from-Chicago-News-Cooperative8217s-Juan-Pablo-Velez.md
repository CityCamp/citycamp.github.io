---
id: 448558482
title: '3 CityCamp take-aways from Chicago News Cooperative&#8217;s Juan-Pablo Velez'
date: 2010-08-05T23:16:31-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/448555545-revision-3/
permalink: /?p=448558482
---
