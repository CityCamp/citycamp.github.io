---
id: 448558646
title: Tim O’Reilly’s CityCamp brainstorm session ‘What Makes a Great City?’
date: 2010-08-19T23:05:15-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/355254130-revision-14/
permalink: /?p=448558646
---
[What Makes a Great City &#8211; #CityCamp Session led by @timoreilly](http://vimeo.com/8951498) from [Peter Corbett](http://vimeo.com/user1065288) on [Vimeo](http://vimeo.com).

Video is by Peter Corbett, [iStrategy Labs](http://istrategylabs.com/ "home page")