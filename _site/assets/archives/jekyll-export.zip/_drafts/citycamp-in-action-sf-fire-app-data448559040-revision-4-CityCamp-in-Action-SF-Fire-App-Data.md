---
id: 448559044
title: 'CityCamp in Action: SF Fire App Data'
date: 2011-06-29T19:04:04-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559040-revision-4/
permalink: /?p=448559044
---
<div style="width: 510px" class="wp-caption alignleft">
  <a href="http://www.flickr.com/photos/adrielhampton/5849707781/in/faves-67403355@N00/"><img loading="lazy" title="Granicus co-founder Javier Muniz shows his day of work on the SF Fire App at CityCampSF." src="http://farm3.static.flickr.com/2673/5849707781_b204201569.jpg" alt="Granicus co-founder Javier Muniz shows his day of work on the SF Fire App at CityCampSF." width="500" height="333" /></a>
  
  <p class="wp-caption-text">
    Granicus co-founder Javier Muniz shows his day of work on the SF Fire App at CityCampSF.
  </p>
</div>

<del>The first rule of Fight Club&#8230;</del>

(Just kidding.)

The fourth goal of CityCamp is: Create outcomes that participants will act upon after the event is over