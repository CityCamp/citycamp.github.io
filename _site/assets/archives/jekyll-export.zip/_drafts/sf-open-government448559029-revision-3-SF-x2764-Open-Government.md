---
id: 448559032
title: 'SF &#x2764; Open Government'
date: 2011-06-15T16:23:49-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559029-revision-3/
permalink: /?p=448559032
---
<div style="width: 660px" class="wp-caption aligncenter">
  <a href="http://sf.govfresh.com/govfresh-guide-to-sfopen-2011/"><img loading="lazy" title="SF Open 2011" src="http://sf.govfresh.com/files/2011/06/sfopen2011post.png" alt="SF Open 211" width="650" height="250" /></a>
  
  <p class="wp-caption-text">
    On Thursday, June 16th, Candidates for Mayor of San Francisco discuss the role open government for their city in a public forum produced by GovFresh
  </p>
</div>

&nbsp;

<div style="width: 950px" class="wp-caption aligncenter">
  <a href="http://citycampsf.govfresh.com"><img loading="lazy" title="CityCamp SF" src="http://citycampsf.govfresh.com/files/2011/02/citycampsfheader4.png" alt="CityCamp San Francisco" width="940" height="198" /></a>
  
  <p class="wp-caption-text">
    On Saturday, June 18th, San Francisco will be the first city to host its 2nd CityCamp
  </p>
</div>