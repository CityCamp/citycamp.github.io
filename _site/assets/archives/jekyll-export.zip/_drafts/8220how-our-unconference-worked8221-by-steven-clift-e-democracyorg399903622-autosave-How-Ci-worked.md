---
id: 448558465
title: How Ci worked
date: 2010-08-05T23:14:48-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/399903622-autosave/
permalink: /?p=448558465
---
