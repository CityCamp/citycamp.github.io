---
id: 448558934
title: Start a Camp
date: 2011-03-11T14:25:26-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558491-revision-38/
permalink: /?p=448558934
---
Thinking about starting a CityCamp where you live?  Great!  Here&#8217;s how:

Anyone can host a CityCamp, and every CityCamp event has its own focus and tone. This document provides a brief overview of the guidelines for creating a successful CityCamp event.  That said, we&#8217;re refining this concept as we go along, so please [share with the community](http://forums.e-democracy.org/groups/citycamp "e-dem forum") if you have suggestions or questions about the information you see here.

# How Do I Host a CityCamp?

If you are thinking about organizing a CityCamp **the very first thing you should do** is [join the community](http://forums.e-democracy.org/groups/citycamp "e-dem forum") and [introduce yourself](http://forums.e-democracy.org/groups/citycamp/messages/topic/3g0GYpJZc9MHOFXlkaDEQL "Introductions thread").

Anyone can host a CityCamp who is committed to organizing an event based on:

  1. The [Four Goals of CityCamp](http://citycamp.com/about)
  2. A few simple rules and responsibilities (see below)

### Rules Governing CityCamp:

  1. <span style="font-weight: normal; font-size: 13px;">All CityCamp events are on the record by default.  Particpants should be made aware that they can and will be quoted, photographed, videoed and otherwise recorded. </span>Exceptions must be agreed to by all parties present in a conversation in order for the conversation to be off the record.
  2. Both public representatives and private citizens must participate.  If one party is absent then the event is not a CityCamp.
  3. All CityCamp events are participatory.  Attendees at each CityCamp are expected to take an active role in the agenda
  4. CityCamp exists in the Creative Commons under the [Attribution, Share-alike License](http://creativecommons.org/licenses/by-sa/3.0/).

### Responsibilities of a Host:

  1. Set a Schedule
  2. Establish Scope and Theme
  3. Book a Venue
  4. Establish a Web Presence
  5. Outfit the Camp
  6. Invite Participants
  7. Cater Your Event
  8. Share Your Event

### <span style="color: #808080;">Set a Schedule (DRAFT)</span>

  * <span style="color: #808080;">3 months before event </span>
  * <span style="color: #808080;">Announce your event</span>
  * <span style="color: #808080;">Launch event&#8217;s Web presence</span>
  * <span style="color: #808080;">Start fundraising</span>
  * <span style="color: #808080;">2-3 months before event</span>
  * <span style="color: #808080;">Lock a venue</span>
  * <span style="color: #808080;">1-2 months before event </span>
  * <span style="color: #808080;">Lock a caterer</span>

### Establish a Scope and Theme:

Set the tone of your local event and help orient participants to relevant topics.  Use the Barcamp Wiki to find themes and topics from past CityCamps.  Schedule [lightning talks](http://en.wikipedia.org/wiki/Lightning_Talk) and pre-program early sessions to initiate inexperienced CityCampers.

#### Get Ideas

Use an &#8220;ideation platform&#8221; like [UserVoice](https://uservoice.com/ "home") or [IdeaScale](http://ideascale.com/ "home") to collect topic and project suggestions and let your campers vote for the topics and projects they like most.  This is a great way to focus your event.  Don&#8217;t discourage, however, break-out sessions that are of interest to only small groups.

### Book a Venue:

Decide how many people you will host and choose an appropriate meeting place.  A public meeting place is preferred.  A single meeting place is preferred.  Where this is not practical or allowable, choose any available space that does not require special access.  Regardless of the number of expected participants or venues, you will need one room that can accommodate all people and multiple, smaller rooms for sessions and breakouts.  Determine whether or not a rental fee is required by the venue.  Consider bartering the cost of the venue in exchange for top billing on event Web sites and promotional communications.

<a name="web"></a>

### <a>Establish a Web Presence:</a>

<a>Use the Web.  All  CityCamps must minimally create a wiki page.  Use wiki pages from other CityCamp cities as guides.  Each CityCamp is invited and encouraged to make use of the online tools that are available to all CityCampers:</a>

Home &#8211; <http://citycamp.com/>  
Wiki &#8211; <http://barcamp.org/CityCamp>  
Forum &#8211; <http://forums.e-democracy.org/groups/citycamp>  
Group &#8211; <http://www.govloop.com/group/citycamp>  
Twitter &#8211; <http://twitter.com/citycamp>  
Bookmarks &#8211; <http://www.delicious.com/tag/citycamp>  
Word Press Theme &#8211; <http://govfresh.com/wp-content/uploads/zip/citycamp.zip>

**All CityCamps must reference these tools in their own Web presence.**

Hosts are encouraged to use event-specific social media tags and pages, ex., [CityCampDC](http://barcamp.org/CityCampDC), [CityCampLDN](http://citycampldn.govfresh.com),[CityCampSF](http://citycampsf.govfresh.com).  **Hosts should not create event-specific forums, e-mail lists, or groups**.  Please invite your campers to participate in the global community. In addition to the e-democracy forum, there are several ways to connect to the community, including [Facebook](http://www.facebook.com/citycamp "facebook") and [Linked In](www.linkedin.com/groups/CityCamp-3766334 "linked.in group page")

#### Accessibility

Make your Web presence accessible to the broadest possible audience.  If your core audience expects high definition and bandwidth then do your best to fulfill that expectation.  If your core audience thrives on mobile SMS then strive equally well to serve that medium.  Regardless of the infrastructure, provide a record of your CityCamp that is accessible to the global CityCamp community.  When in doubt, it&#8217;s better to do a CityCamp event with the best tools and bandwidth you can put together than cancel the idea because all the logistics aren&#8217;t perfect

### Outfit the Camp:

Make sure your event has the resources it needs.  You may require financial support to pay for expenses such as venue, catering, and social mixers.  Hosts are responsible for ensuring that these needs are met.  While sponsorship terms may vary, hosts must never allow any sponsor the privilege of setting the agenda for the event.  Bartering services in exchange for sponsor promotion is encouraged.  Some venues and caterers will discount and trade for recognition on Web sites and promotional communications.  We recommend the following sponsorship levels:  CityCamp Partner @ $500, CityCamp Supporter @ $250, Friend of CityCamp @ no set amount (contributor&#8217;s choice).

### Invite Participants:

See Goal #1.  See Rule #2.  Include a registration page in your Web presence.  Using an event registration service is recommended.  Reach out directly to your local networks to extend verbal and written invitations.  When inviting participants who are not local, consider that they may have travel expenses.  Be clear with invitees about how travel expenses are to be paid.

### Cater Your Event:

Fuel your Campers&#8217; bodies as well as their minds.  Depending on the length of your event and the number of expected participants, plan to provide morning, lunch, and afternoon refreshments for each full day.

### Share Your Event:

Let people know what&#8217;s happening before, during, and after your event.  Use the &#8220;citycamp&#8221; tag and your CityCamp&#8217;s tag for all blog posts, photos, videos, tweets, and the like.  
<a name="whatcity"></a>

### Does a CityCamp have to be about just one city?

No, but it should be about a recognized place.  Many cities can come together under one CityCamp.   In fact, CityCamp doesn&#8217;t have to be about a &#8220;city&#8221; at all.  CityCamps work in counties, towns, villages, and regions, to name a few variations.  CityCamps are about connecting a global, collective knowledge to local needs and opportunities using the Web as a platform. CityCamps address governments where we live.

<a name="form"></a>  
[contact-form 1 &#8220;Contact form 1&#8221;]