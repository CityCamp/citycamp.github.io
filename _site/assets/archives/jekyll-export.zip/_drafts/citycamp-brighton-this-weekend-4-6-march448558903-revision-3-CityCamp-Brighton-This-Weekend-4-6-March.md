---
id: 448558906
title: CityCamp Brighton This Weekend, 4-6 March
date: 2011-02-28T12:36:17-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448558903-revision-3/
permalink: /?p=448558906
---
**Friday 4th March – Sunday 6th March 2011**  
[  
CityCampBTN](http://www.citycampbtn.org/) is about rethinking the way the web, technology and participation will shape the future of our city.

It doesn’t matter whether you’re someone with a great idea or a problem to solve, or if you’re a developer with specific skills – if you’re passionate about our city and want to be inspired to create new solutions, then this is for you.

We’ve lined up three days of inspiring speakers, discussions powered by you and hands-on building of solutions. And it’s free.

Part of the [CityCamp](http://www.citycamp.com/) movement, started in Chicago last year, CityCamp BTN brings together local government, business, community sector and academic communities, to work together.

[Register your place now!](http://citycampbtn.eventbrite.com/)

&nbsp;