---
id: 448559209
title: CityCampSF Hackathon Set for December 10-11
date: 2011-11-17T12:28:04-05:00
author: Kevin Curry
layout: revision
guid: http://citycamp.govfresh.com/448559205-revision-4/
permalink: /?p=448559209
---
<div id="intro">
  <p>
    <a href="http://www.flickr.com/photos/adrielhampton/6278046596"><img loading="lazy" src="http://farm7.static.flickr.com/6108/6278046596_64b3dc68e8.jpg" alt="" width="500" height="375" border="0" /></a>
  </p>
  
  <p>
    <a title="CCSF home" href="http://citycampsf.govfresh.com/" target="_blank">CityCampSF</a>, <a title="G2R home" href="http://www.gov20radio.com/" target="_blank">Gov 2.0 Radio</a>, <a title="OpenSF home" href="http://opensf.wordpress.com/" target="_blank">OpenSF</a>, <a title="TTSF home" href="https://www.facebook.com/ThirdThursdaysSF" target="_blank">Third Thursdays SF</a> and <a title="Granicus home" href="http://www.granicus.com/Streaming-Media-Government.aspx" target="_blank">Granicus</a> are hosting <strong><em>24 hours</em></strong> of civic innovation.
  </p>
  
  <p>
    Challenges include:
  </p>
  
  <p>
    Best demonstration app for assessing the impacts of clear-cutting in the Sierra Nevadas;
  </p>
  
  <p>
    Best app combining City data sources for transparency in SF campaign donations, lobbying and contracting;
  </p>
  
  <p>
    Best use of Granicus <a title="Granicus Developer Site" href="http://www.granicus.com/Support/Developers.aspx" target="_blank">APIs</a>;
  </p>
  
  <p>
    Submit a challenge and ask questions on the <a href="http://www.wiredtoshare.com/citycampsf_hackathon_projects" target="_blank">CityCampSF Hackathon Projects page</a>.
  </p>
  
  <p>
    The event will also launch an advocacy campaign for structured open data definitions in San Francisco municipal and California state law. Endorse that effort <a href="http://www.wiredtoshare.com/structured_open_data_campaign" target="_blank">here</a>.
  </p>
  
  <p>
    Contribute funds to cover the cost of the event <a title="National Builder Fundraising Site" href="https://adriel.nationbuilder.com/donate" target="_blank">here, at Nation Builder</a>.
  </p>
</div>

<div>
  <div>
    WHEN
  </div>
  
  <div>
    December 10, 2011 at 12:00 PM &#8211; December 11, 2011 at 12:00 PM
  </div>
</div>

<div>
  <div>
    WHERE
  </div>
  
  <div>
    Granicus<br /> 600 Harrison St<br /> Suite 120<br /> San Francisco, CA 94107<br /> <a href="http://maps.google.com/maps?q=600+Harrison+St%2C+San+Francisco%2C+CA+94107">Google map and directions</a>
  </div>
</div>

<div>
  <div>
    CONTACT
  </div>
  
  <div>
    Adriel Hampton · <a title="" href="mailto:adriel@adrielhampton.com">adriel@adrielhampton.com</a> · 415-237-4299
  </div>
</div>