---
id: 448558475
title: Connect
date: 2010-08-05T23:30:25-05:00
author: Luke Fretwell
layout: revision
guid: http://citycamp.govfresh.com/7-revision-6/
permalink: /?p=448558475
---
How do I connect with CityCampers?

  * Twitter: <a href="http://twitter.com/CityCamp" target="_blank">@CityCamp</a>
  * Hashtags:  [#citycamp](http://twitter.com/#search?q=citycamp)
  * E-mail List: <http://forums.e-democracy.org/groups/citycamp>
  * Facebook: <http://www.facebook.com/group.php?gid=130953577981>
  * GovLoop: <http://www.govloop.com/group/citycamp>
  * Delicious: <http://delicious.com/tag/CityCamp>
  * USE YOUR OWN LOCAL CHANNELS TO CONNECT DURING YOUR OWN CAMPS

<!--GroupSever Signup Form-->