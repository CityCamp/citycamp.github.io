---
id: 5
title: Calendar
date: 2010-08-03T21:23:52-05:00
author: Kevin Curry
layout: page
guid: http://citycamp.govfresh.com/
dsq_thread_id:
  - "436165701"
hefo_before:
  - "0"
hefo_after:
  - "0"
swp_pinterest_image_url:
  - ""
swp_cache_timestamp:
  - "428803"
dpsp_networks_shares:
  - 'a:1:{s:9:"pinterest";i:0;}'
dpsp_networks_shares_total:
  - "0"
dpsp_networks_shares_last_updated:
  - "1632207112"
---
Join the [CityCamp Exchange](http://e-democracy.org/citycamp) to learn about emerging events before they get listed here.